/*
 * Database - static placeholder for any kind of persistence in this example
 * Code-Beispiel zum Buch Patterns Kompakt, Spektrum Akademischer Verlag
 * Copyright 2012 Karl Eilebrecht
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package de.calamanari.pk.transferobjectassembler;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

/**
 * Database - static placeholder for any kind of persistence in this example
 * @author <a href="mailto:Karl.Eilebrecht(a/t)freenet.de">Karl Eilebrecht</a>
 */
public class Database {

	/**
	 * logger
	 */
	protected static final Logger LOGGER = Logger.getLogger(Database.class.getName());
	
	
	/**
	 * The "database table" for customers
	 */
	public static final Map<String, CustomerEntity> CUSTOMERS = new HashMap<String, CustomerEntity>();

	/**
	 * The "database table" for customer addresses
	 */
	public static final Map<String, AddressEntity> ADDRESSES = new HashMap<String, AddressEntity>();

	/**
	 * The "database table" for dwh data
	 */
	public static final Map<String, CustomerDwhInfoEntity> CUSTOMER_DWH_INFOS = new HashMap<String, CustomerDwhInfoEntity>();
	
	/**
	 * For testing this allows to feed the "database"
	 * @param customerId
	 * @param title
	 * @param lastName
	 * @param firstName
	 * @param phone
	 * @param email
	 * @param promotionOptIn
	 * @param addressId
	 * @param street
	 * @param zipCode
	 * @param city
	 * @param country
	 * @param salutation
	 * @param customerType
	 * @param scorePoints
	 * @param firstOrderDateISO 'yyyy-MM-dd'
	 * @param lastOrderDateISO 'yyyy-MM-dd'
	 * @param dueInvoice
	 * @param fraudSuspicion
	 * @param badPayer
	 */
	public static void addTestData(String customerId, String title, String lastName, String firstName, String phone, String email, boolean promotionOptIn,
			String addressId, String street, String zipCode, String city, String country, String salutation, String customerType, int scorePoints,
			String firstOrderDateISO, String lastOrderDateISO, boolean dueInvoice, boolean fraudSuspicion, boolean badPayer) {

		Date firstOrderDate = null;
		Date lastOrderDate = null;

		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			firstOrderDate = (firstOrderDateISO == null ? null : sdf.parse(firstOrderDateISO));
			lastOrderDate = (lastOrderDateISO == null ? null : sdf.parse(lastOrderDateISO));
		}
		catch (Exception ex) {
			throw new RuntimeException(ex);
		}

		CustomerEntity customer = new CustomerEntity(customerId, title, lastName, firstName, phone, email, promotionOptIn);
		CUSTOMERS.put(customerId, customer);
		AddressEntity address = new AddressEntity(addressId, customerId, street, zipCode, city, country, salutation);
		ADDRESSES.put(customerId, address);

		CustomerDwhInfoEntity customerDwhInfo = new CustomerDwhInfoEntity(customerId, customerType, scorePoints, firstOrderDate, lastOrderDate, dueInvoice,
				fraudSuspicion, badPayer);
		CUSTOMER_DWH_INFOS.put(customerId, customerDwhInfo);
	}
	
}
