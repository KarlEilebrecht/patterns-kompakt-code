/*
 * Simple Number sequence is a concrete component to be decorated applying the DECORATOR pattern
 * Code-Beispiel zum Buch Patterns Kompakt, Spektrum Akademischer Verlag
 * Copyright 2012 Karl Eilebrecht
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package de.calamanari.pk.decorator;

import java.util.logging.Logger;

import de.calamanari.pk.sequenceblock.SequenceBlockCache;

/**
 * Simple Number sequence is a concrete component to be decorated applying the DECORATOR pattern<br>
 * This implementation is thread-safe.
 * @author <a href="mailto:Karl.Eilebrecht(a/t)freenet.de">Karl Eilebrecht</a>
 */
public class SimpleNumberSequence implements NumberSequence {

	/**
	 * logger
	 */
	private static final Logger LOGGER = Logger.getLogger(SimpleNumberSequence.class.getName());
	
	
	/**
	 * name of the sequence
	 */
	private final String sequenceName;

	/**
	 * Creates new sequence of the given name
	 * @param sequenceName name of sequence
	 */
	public SimpleNumberSequence(String sequenceName) {
		this.sequenceName = sequenceName;
	}

	@Override
	public long getNextId() {
		long id = SequenceBlockCache.GLOBAL_INSTANCE.getNextId(sequenceName);
		LOGGER.finest("created id=" + id);
		return id;
	}

	@Override
	public String getSequenceName() {
		return sequenceName;
	}	
	
}
