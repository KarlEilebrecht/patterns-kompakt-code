/*
 * Optimistic Offline Lock Test - demonstrates OPTIMISTIC OFFLINE LOCK pattern.
 * Code-Beispiel zum Buch Patterns Kompakt, Spektrum Akademischer Verlag
 * Copyright 2012 Karl Eilebrecht
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package de.calamanari.pk.optimisticofflinelock.test;

import static org.junit.Assert.*;

import java.util.ConcurrentModificationException;
import java.util.concurrent.CountDownLatch;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.BeforeClass;
import org.junit.Test;


import de.calamanari.pk.optimisticofflinelock.Customer;
import de.calamanari.pk.optimisticofflinelock.DataManager;
import de.calamanari.pk.util.LogUtils;
import de.calamanari.pk.util.MiscUtils;

/**
 * Optimistic Offline Lock Test - demonstrates OPTIMISTIC OFFLINE LOCK pattern.
 * @author <a href="mailto:Karl.Eilebrecht(a/t)freenet.de">Karl Eilebrecht</a>
 */
public class OptimisticOfflineLockTest {

	/**
	 * logger
	 */
	protected static final Logger LOGGER = Logger.getLogger(OptimisticOfflineLockTest.class.getName());

	/**
	 * Log-level for this test
	 */
	private static final Level LOG_LEVEL = Level.INFO; 
	
	/**
	 * for thread coordination
	 */
	private final CountDownLatch countDown = new CountDownLatch(2);
	
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		LogUtils.setConsoleHandlerLogLevel(LOG_LEVEL);
		LogUtils.setLogLevel(LOG_LEVEL, OptimisticOfflineLockTest.class, DataManager.class);
		DataManager.addCustomer("4711", "Jack", "Miller", "17, Citrus Ave", "286736", "Lemon Village");
	}
	
	
	
	@Test
	public void testOptimisticOfflineLock() throws Exception {

		// Adjust the log-level above to FINE to see the OPTIMISTIC OFFLINE LOCK working
		
		LOGGER.info("Test Optimistic Offline Lock ...");
		long startTimeNanos = System.nanoTime();
		
		firstUserStartsToWork();
		secondUserStartsToWork();
		
		countDown.await();
		
		assertEquals("Customer({customerId='4711', lastName='Miller', firstName='Jane', street='19, Lucky Road', zipCode='286736', city='Lemon Village', version=2})", 
				DataManager.findCustomerById("4711").toString());
		
		LOGGER.info("Test Optimistic Offline Lock successful! Elapsed time: " + MiscUtils.formatNanosAsSeconds(System.nanoTime() - startTimeNanos) + " s");
	}


	/**
	 * First user works on the record
	 */
	private void firstUserStartsToWork() {
		(new Thread("User_1") {
			
			public void run() {
				Customer customer = DataManager.findCustomerById("4711");
				customer.setStreet("19, Lucky Road");
				MiscUtils.delay(5000);
				try {
					DataManager.storeCustomer(customer);
				}
				catch (Exception ex) {
					assertTrue(ex instanceof ConcurrentModificationException);
				}
				// oops, user 1 was too optimistic, let's try again
				customer = DataManager.findCustomerById("4711");
				customer.setStreet("19, Lucky Road");
				DataManager.storeCustomer(customer);
				countDown.countDown();
			}
			
		}).start();
	}

	/**
	 * First user works concurrently on the record
	 */
	private void secondUserStartsToWork() {
		(new Thread("User_2") {
			public void run() {
				MiscUtils.delay(2000);
				Customer customer = DataManager.findCustomerById("4711");
				customer.setFirstName("Jane");
				DataManager.storeCustomer(customer);
				countDown.countDown();
			}
			
		}).start();
	}
	
}
