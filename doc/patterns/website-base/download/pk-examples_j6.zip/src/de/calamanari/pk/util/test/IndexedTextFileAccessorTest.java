/*
 * IndexedTextFileAccessorTest
 * Code-Beispiel zum Buch Patterns Kompakt, Spektrum Akademischer Verlag
 * Copyright 2012 Karl Eilebrecht
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package de.calamanari.pk.util.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.util.Arrays;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import de.calamanari.pk.util.IndexedTextFileAccessor;
import de.calamanari.pk.util.LogUtils;
import de.calamanari.pk.util.MiscUtils;

/**
 * IndexedTextFileAccessorTest - some tests for IndexedTextFileAccessor class
 * @author <a href="mailto:Karl.Eilebrecht(a/t)freenet.de">Karl Eilebrecht</a>
 */
public class IndexedTextFileAccessorTest {

	/**
	 * logger
	 */
	private static final Logger LOGGER = Logger.getLogger(IndexedTextFileAccessorTest.class.getName());
	
	/**
	 * Log-level for this test
	 */
	private static final Level LOG_LEVEL = Level.INFO; 
	
	
	/**
	 * Defines whether the huge file (ca. 1GB) should be created for testing or not
	 */
	private static final boolean HUGE_TEST_ALLOWED = false;
	
	/**
	 * Charset for test, we use "UTF-8" to test multi-byte decoding
	 */
	private static final String CHARSET_NAME = "UTF-8";
	
	/**
	 * Length in bytes of line break (depends on OS)
	 */
	private static final int LINE_BREAK_SIZE_IN_BYTES;
	static {
		int res = 1;
		Properties prop = System.getProperties( );
		String osName = prop.getProperty("os.name");
		if (osName != null && osName.toLowerCase().indexOf("windows") > -1) {
			res = 2;
		}
		LINE_BREAK_SIZE_IN_BYTES = res;
	}
	
	/**
	 * verly large file
	 */
	private static File huge1000000LinesFile = null;
	
	/**
	 * empty File
	 */
	private static File emptyFile = null;
	
	/**
	 * File with 3 empty lines only.
	 */
	private static File onlyEmptyLines3File = null;
	
	
	/**
	 * File with one character
	 */
	private static File singleCharFile = null;
	
	/**
	 * File with one line
	 */
	private static File singleLineFile = null;
	
	/**
	 * File with one line followed by new line
	 */
	private static File singleLinePlusNewLineFile = null;
	
	/**
	 * File with odd number (3) of characters
	 */
	private static File oddChar3NumFile = null;
	
	/**
	 * File with even number (4) of characters
	 */
	private static File evenChar4NumFile = null;

	/**
	 * File with odd number (3) of lines
	 */
	private static File oddLine3NumFile = null;

	/**
	 * File with even number (4) of lines
	 */
	private static File evenLine4NumFile = null;
	
	/**
	 * File with many (1000) lines
	 */
	private static File multiLines1000File = null;
	
	/**
	 * Test string
	 */
	private static final String MULTI_LINE_BASE = " ----> \u00C4\u00D6\u00DC!";
	
	/**
	 * Test string
	 */
	private static final String HUGE_LINE_BASE = " --------> \u00C4\u00D6\u00DC!01234567890123456789";
	
	
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		LogUtils.setConsoleHandlerLogLevel(LOG_LEVEL);
		LogUtils.setLogLevel(LOG_LEVEL, IndexedTextFileAccessorTest.class, IndexedTextFileAccessor.class);
		
		emptyFile = MiscUtils.createTextFile("emptyFile_" + CHARSET_NAME + ".txt", null, CHARSET_NAME);
		onlyEmptyLines3File = MiscUtils.createTextFile("onlyEmptyLines3File_" + CHARSET_NAME + ".txt", Arrays.asList(new String[]{"", "\r"}), CHARSET_NAME);
		singleCharFile = MiscUtils.createTextFile("singleCharFile_" + CHARSET_NAME + ".txt", Arrays.asList(new String[]{"\u00C4"}), CHARSET_NAME);
		singleLineFile = MiscUtils.createTextFile("singleLineFile_" + CHARSET_NAME + ".txt", Arrays.asList(new String[]{"\u00C4 is a german letter."}), CHARSET_NAME);
		singleLinePlusNewLineFile = MiscUtils.createTextFile("singleLinePlusNewLineFile_" + CHARSET_NAME + ".txt", Arrays.asList(new String[]{"\u00C4 is a german letter.", ""}), CHARSET_NAME);
		oddChar3NumFile = MiscUtils.createTextFile("oddChar3NumFile_" + CHARSET_NAME + ".txt", Arrays.asList(new String[]{"\u00C4\u00D6\u00DC"}), CHARSET_NAME);
		evenChar4NumFile = MiscUtils.createTextFile("evenChar4NumFile_" + CHARSET_NAME + ".txt", Arrays.asList(new String[]{"\u00C4\u00D6\u00DC!"}), CHARSET_NAME);
		oddLine3NumFile = MiscUtils.createTextFile("oddLine3NumFile_" + CHARSET_NAME + ".txt", Arrays.asList(
				new String[]{
					"\u00C4 is a german letter.", 
					"\u00D6 is a german letter.",
					"\u00DC is a german letter."}), CHARSET_NAME);
		evenLine4NumFile = MiscUtils.createTextFile("evenLine4NumFile_" + CHARSET_NAME + ".txt", Arrays.asList(
				new String[]{
					"\u00C4 is a german letter.", 
					"\u00D6 is a german letter.",
					"\u00DC is a german letter.",
					"Lorem ipsum."}), CHARSET_NAME);
		String[] manyLines = new String[1000];
		
		for (int i = 0; i < 1000; i++) {
			manyLines[i]  = "" + i + MULTI_LINE_BASE;
		}
		multiLines1000File = MiscUtils.createTextFile("multiLines1000File_" + CHARSET_NAME + ".txt", Arrays.asList(manyLines), CHARSET_NAME);
		
		if (HUGE_TEST_ALLOWED) {
			long startTimeNanos = System.nanoTime();
			LOGGER.info("Creating huge file ... ");
			huge1000000LinesFile = createHugeFile("hugeFile1000000_" + CHARSET_NAME + ".txt");
			LOGGER.info("Huge file '" + huge1000000LinesFile + "' created after " + MiscUtils.formatNanosAsSeconds(System.nanoTime() - startTimeNanos) + " s.");
		}

	}
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		emptyFile.delete();
		onlyEmptyLines3File.delete();
		singleCharFile.delete();
		singleLineFile.delete();
		singleLinePlusNewLineFile.delete();
		oddChar3NumFile.delete();
		evenChar4NumFile.delete();
		oddLine3NumFile.delete();
		evenLine4NumFile.delete();
		multiLines1000File.delete();
		if (HUGE_TEST_ALLOWED) {
			System.gc();
			Thread.sleep(5000);
			huge1000000LinesFile.delete();
			huge1000000LinesFile = null;
		}
	}

	@Test
	public void testEmptyFile() throws Exception {
		IndexedTextFileAccessor ifa = new IndexedTextFileAccessor(emptyFile, CHARSET_NAME);
		assertEquals(0, ifa.getFileSize());
		assertEquals(0, ifa.getNumberOfCharacters());
		assertEquals(0, ifa.getNumberOfLines());
		assertEquals(0, ifa.getNumberOfCharacterIndexEntries());
		assertEquals(0, ifa.getNumberOfLineIndexEntries());
	}

	@Test
	public void testOnlyEmptyLines3File() throws Exception {
		IndexedTextFileAccessor ifa = new IndexedTextFileAccessor(onlyEmptyLines3File, CHARSET_NAME);
		assertEquals(1 + LINE_BREAK_SIZE_IN_BYTES, ifa.getFileSize()); // 1
		assertEquals(1 + LINE_BREAK_SIZE_IN_BYTES, ifa.getNumberOfCharacters());
		assertEquals(3, ifa.getNumberOfLines());
		assertEquals(1 + LINE_BREAK_SIZE_IN_BYTES, ifa.getNumberOfCharacterIndexEntries());
		assertEquals(3, ifa.getNumberOfLineIndexEntries());
		
		assertEquals("", readLineAndClose(ifa.createInputStreamReaderAtLine(1)));		
		//implicit line after last character, must be null
		assertEquals(null, readLineAndClose(ifa.createInputStreamReaderAtLine(2)));		
	}
	
	@Test
	public void testSingleCharFile() throws Exception {
		IndexedTextFileAccessor ifa = new IndexedTextFileAccessor(singleCharFile, CHARSET_NAME);
		assertEquals(2, ifa.getFileSize());
		assertEquals(1, ifa.getNumberOfCharacters());
		assertEquals(1, ifa.getNumberOfLines());
		assertEquals(1, ifa.getNumberOfCharacterIndexEntries());
		assertEquals(1, ifa.getNumberOfLineIndexEntries());
		assertEquals("\u00C4", readAndClose(ifa.createInputStreamReaderAtChar(0), 1));		
	}

	@Test
	public void testSingleLineFile() throws Exception {
		IndexedTextFileAccessor ifa = new IndexedTextFileAccessor(singleLineFile, CHARSET_NAME);
		assertEquals(22, ifa.getFileSize());
		assertEquals(21, ifa.getNumberOfCharacters());
		assertEquals(1, ifa.getNumberOfLines());
		assertEquals(21, ifa.getNumberOfCharacterIndexEntries());
		assertEquals(1, ifa.getNumberOfLineIndexEntries());
	}

	@Test
	public void testSingleLinePlusNewLineFile() throws Exception {
		IndexedTextFileAccessor ifa = new IndexedTextFileAccessor(singleLinePlusNewLineFile, CHARSET_NAME);
		assertEquals(22 + LINE_BREAK_SIZE_IN_BYTES, ifa.getFileSize()); // 1
		assertEquals(21 + LINE_BREAK_SIZE_IN_BYTES, ifa.getNumberOfCharacters());
		assertEquals(2, ifa.getNumberOfLines());
		assertEquals(21 + LINE_BREAK_SIZE_IN_BYTES, ifa.getNumberOfCharacterIndexEntries());
		assertEquals(2, ifa.getNumberOfLineIndexEntries());
	}
	
	@Test
	public void testOddChar3NumFile() throws Exception {
		IndexedTextFileAccessor ifa = new IndexedTextFileAccessor(oddChar3NumFile, CHARSET_NAME);
		assertEquals(6, ifa.getFileSize());
		assertEquals(3, ifa.getNumberOfCharacters());
		assertEquals(1, ifa.getNumberOfLines());
		assertEquals(3, ifa.getNumberOfCharacterIndexEntries());
		assertEquals(1, ifa.getNumberOfLineIndexEntries());
	}
	
	@Test
	public void testEvenChar4NumFile() throws Exception {
		IndexedTextFileAccessor ifa = new IndexedTextFileAccessor(evenChar4NumFile, CHARSET_NAME);
		assertEquals(7, ifa.getFileSize());
		assertEquals(4, ifa.getNumberOfCharacters());
		assertEquals(1, ifa.getNumberOfLines());
		assertEquals(4, ifa.getNumberOfCharacterIndexEntries());
		assertEquals(1, ifa.getNumberOfLineIndexEntries());
	}
	
	@Test
	public void testOddLine3NumFile() throws Exception {
		IndexedTextFileAccessor ifa = new IndexedTextFileAccessor(oddLine3NumFile, CHARSET_NAME);
		assertEquals(66 + (2 * LINE_BREAK_SIZE_IN_BYTES), ifa.getFileSize()); // 2
		assertEquals(63 + (2 * LINE_BREAK_SIZE_IN_BYTES), ifa.getNumberOfCharacters());
		assertEquals(3, ifa.getNumberOfLines());
		assertEquals(63 + (2 * LINE_BREAK_SIZE_IN_BYTES), ifa.getNumberOfCharacterIndexEntries());
		assertEquals(3, ifa.getNumberOfLineIndexEntries());
	}
	
	@Test
	public void testEvenLine4NumFile() throws Exception {
		IndexedTextFileAccessor ifa = new IndexedTextFileAccessor(evenLine4NumFile, CHARSET_NAME);
		assertEquals(78 + (3 * LINE_BREAK_SIZE_IN_BYTES), ifa.getFileSize()); // 3
		assertEquals(75 + (3 * LINE_BREAK_SIZE_IN_BYTES), ifa.getNumberOfCharacters());
		assertEquals(4, ifa.getNumberOfLines());
		assertEquals(75 + (3 * LINE_BREAK_SIZE_IN_BYTES), ifa.getNumberOfCharacterIndexEntries());
		assertEquals(4, ifa.getNumberOfLineIndexEntries());
	}

	@Test
	public void testMultiLines1000File() throws Exception {
		//use a too small index
		IndexedTextFileAccessor ifa = new IndexedTextFileAccessor(multiLines1000File, CHARSET_NAME, 250, 250, 0);
		assertEquals(16890 + (999 * LINE_BREAK_SIZE_IN_BYTES), ifa.getFileSize()); // 999
		assertEquals(13890 + (999 * LINE_BREAK_SIZE_IN_BYTES), ifa.getNumberOfCharacters());
		assertEquals(1000, ifa.getNumberOfLines());
		assertEquals(248, ifa.getNumberOfCharacterIndexEntries());
		assertEquals(245, ifa.getNumberOfLineIndexEntries());
		
		for (int i = 0; i < 1000; i++) {
			assertEquals("" + i + MULTI_LINE_BASE, readLineAndClose(ifa.createInputStreamReaderAtLine(i)));
		}
		
		assertEquals(MULTI_LINE_BASE, readLineAndClose(ifa.createInputStreamReaderAtChar(122 + (10 * LINE_BREAK_SIZE_IN_BYTES)))); //142
		
	}
	
	
	
	@Test
	public void test1000000LinesFile() throws Exception {
		if (HUGE_TEST_ALLOWED)  {
			long startTimeNanos = System.nanoTime();
			LOGGER.info("Creating IndexedTextFileAccessor ... ");
			IndexedTextFileAccessor ifa = new IndexedTextFileAccessor(huge1000000LinesFile, CHARSET_NAME);
			LOGGER.info("Index ready after " + MiscUtils.formatNanosAsSeconds(System.nanoTime() - startTimeNanos) + " s.");
			assertEquals(1145888890 + (999999 * LINE_BREAK_SIZE_IN_BYTES), ifa.getFileSize()); //999999
			assertEquals(1055888890 + (999999 * LINE_BREAK_SIZE_IN_BYTES), ifa.getNumberOfCharacters());
			assertEquals(1000000, ifa.getNumberOfLines());
			assertTrue(9990 < ifa.getNumberOfCharacterIndexEntries());
			assertTrue(9980 < ifa.getNumberOfLineIndexEntries());
			assertEquals("---> \u00C4\u00D6\u00DC!01234567890123456789", readLineAndClose(ifa.createInputStreamReaderAtChar(998105 + (947 * LINE_BREAK_SIZE_IN_BYTES)))); //947
			String s = readLineAndClose(ifa.createInputStreamReaderAtLine(999999));
			assertEquals(1056, s.length());
			assertEquals("999999 --------> \u00C4\u00D6\u00DC!01234567890123456789", s.substring(0, 41));
		}
		
		
	}

	/**
	 * helper to read some characters and close the file
	 * @param isr reader from index
	 * @param length characters to read
	 * @return string with characters
	 * @throws Exception
	 */
	private String readAndClose(Reader isr, int length) throws Exception {
		StringBuilder sb = new StringBuilder();
		try {
			for (int i = 0; i < length; i++) {
				sb.append((char)isr.read());
			}
		}
		finally {
			try {
				isr.close();
			}
			catch (Throwable t) {
				//ignore
			}
		}
		return sb.toString();
	}

	/**
	 * helper to read some characters and close the file
	 * @param isr reader from index
	 * @param length characters to read
	 * @return string with characters
	 * @throws Exception
	 */
	private String readLineAndClose(Reader isr) throws Exception {
		String res = null;
		try {
			BufferedReader br = new BufferedReader(isr);
			res = br.readLine();
		}
		finally {
			try {
				isr.close();
			}
			catch (Throwable t) {
				//ignore
			}
		}
		return res;
	}

	
	/**
	 * Creates the huge file with 1000000 lines
	 * @param fileName name of file without path
	 * @return new file
	 * @throws Exception
	 */
	private static File createHugeFile(String fileName) throws Exception {
		File file = new File(MiscUtils.getHomeDirectory(), fileName);
		
		StringBuilder line = new StringBuilder();
		for (int i = 0; i < 30; i++) {
			line.append(HUGE_LINE_BASE);
		}
		BufferedWriter bw = null;
		try {
			bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), CHARSET_NAME), 1048576);
			for (int i = 0; i < 1000000; i++) {
				if (i > 0) {
					bw.newLine();
				}
				bw.append("" + i);
				bw.append(line);
			}
		}
		finally {
			if (bw != null) {
				bw.close();
			}
		}
		return file;
	}
	
}
