/*
 * Master Slave Test - demonstrates MASTER SLAVE pattern.
 * Code-Beispiel zum Buch Patterns Kompakt, Spektrum Akademischer Verlag
 * Copyright 2012 Karl Eilebrecht
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package de.calamanari.pk.masterslave.test;

import static org.junit.Assert.assertEquals;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.BeforeClass;
import org.junit.Test;

import de.calamanari.pk.masterslave.PalindromeCheckFuture;
import de.calamanari.pk.masterslave.PalindromeCheckMaster;
import de.calamanari.pk.masterslave.PalindromeCheckResult;
import de.calamanari.pk.masterslave.PalindromeCheckSlaveTask;
import de.calamanari.pk.util.LogUtils;
import de.calamanari.pk.util.MiscUtils;

/**
 * Master Slave Test - demonstrates MASTER SLAVE pattern.
 * @author <a href="mailto:Karl.Eilebrecht(a/t)freenet.de">Karl Eilebrecht</a>
 */
public class MasterSlaveTest {

	/**
	 * logger
	 */
	private static final Logger LOGGER = Logger.getLogger(MasterSlaveTest.class.getName());

	/**
	 * Character set for the test
	 */
	public static final String CHARSET_NAME = "UTF-8";
	
	/**
	 * Allowed characters including some German umlauts which will need two bytes encoded using UTF-8
	 */
	public static final char[] CHARACTERS = "\u00C4\u00D6\u00DCABCDEFGHIJKLMNOPQRSTUVWXYZ01234567890123456789".toCharArray();
	
	/**
	 * Number of available characters
	 */
	public static final int NUMBER_OF_CHARACTERS = CHARACTERS.length;
	
	/**
	 * Number of characters in the palindrome
	 */
	public static final int PALINDROME_SIZE = 1111111; // 1GB = 1073741824;  
	
	/**
	 * Log-level for this test
	 */
	private static final Level LOG_LEVEL = Level.INFO; 

	/**
	 * number of slaves (worker threads)
	 */
	private static final int NUMBER_OF_SLAVES = Runtime.getRuntime().availableProcessors();
	
	/**
	 * size of partition each slave works on
	 */
	private static final int SLAVE_PARTITION_SIZE = 10000;
	
	
	/**
	 * the MASTER
	 */
	private	PalindromeCheckMaster palindromeCheckMaster = new PalindromeCheckMaster(NUMBER_OF_SLAVES, SLAVE_PARTITION_SIZE);

	
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		LogUtils.setConsoleHandlerLogLevel(LOG_LEVEL);
		LogUtils.setLogLevel(LOG_LEVEL, MasterSlaveTest.class, PalindromeCheckMaster.class, 
				PalindromeCheckSlaveTask.class, PalindromeCheckFuture.class, PalindromeCheckResult.class);
	}
	
	@Test
	public void testMasterSlavePalindrome() throws Exception {
		
		// HINTS:
		// * Adjust the log-level above to FINE to see the MASTER SLAVE working
		// * Play with the settings for PALINDROME_SIZE / NUMBER_OF_SLAVES / SLAVE_PARTITION_SIZE and watch execution time and memory consumption
		// * Palindrome creation (below) uses the same approach, try to improve it!
		// * The class IndexedTextFileAccessor used in this example internally uses Master-Slave to improve indexing performance

		File testFile = createPalindromeTestFile(PALINDROME_SIZE, null);		
		
		LOGGER.info("Test Master Slave Palindrome ...");
		long startTimeNanos = System.nanoTime();

		
		PalindromeCheckResult checkResult = palindromeCheckMaster.performPalindromeFileTest(testFile, CHARSET_NAME);
		
		assertEquals(PalindromeCheckResult.CONFIRMED, checkResult);
		
		
		LOGGER.info("Test Master Slave Palindrome successful! Elapsed time: " + MiscUtils.formatNanosAsSeconds(System.nanoTime() - startTimeNanos) + " s");
		
		testFile.delete();
		
	}

	@Test
	public void testMasterSlaveNonPalindrome() throws Exception {

		int errorPositionLeft = (PALINDROME_SIZE / 4);
		int errorPositionRight = (PALINDROME_SIZE - 1) - errorPositionLeft;
		File testFile = createPalindromeTestFile(PALINDROME_SIZE, new int[]{errorPositionLeft});
		
		LOGGER.info("Test Master Slave Non Palindrome ...");
		long startTimeNanos = System.nanoTime();
		
		PalindromeCheckResult checkResult = palindromeCheckMaster.performPalindromeFileTest(testFile, CHARSET_NAME);
		
		assertEquals(PalindromeCheckResult.createFailedResult(errorPositionLeft, errorPositionRight), checkResult);
		
		LOGGER.info("Test Master Slave Non Palindrome successful! Elapsed time: " + MiscUtils.formatNanosAsSeconds(System.nanoTime() - startTimeNanos) + " s");

		testFile.delete();
		
	}
	
	
	/**
	 * Creates a test file for palindrome check with optional error positions. Without
	 * error positions a palindrome will be created.
	 * @param size the size (in characters) of the sample to be created
	 * @param errorPositions all error positions must be in the first half of the palindrome, may be null
	 * @return test file
	 * @throws Exception
	 */
	private File createPalindromeTestFile(int size, int[] errorPositions) throws Exception {
		
		
		
		if (errorPositions == null) {
			errorPositions = new int[0];
		}


		
		int numberOfErrorPositions = errorPositions.length;		
		File res = null;
		res = new File(MiscUtils.getHomeDirectory(), "palindrome_test_" + CHARSET_NAME + "_" + size + "_err=" + numberOfErrorPositions + ".txt");

		LOGGER.info("Creating palindrome test file " + res + " ...");
		
		int halfSize = size / 2;
		
		int numberOfThreads = Runtime.getRuntime().availableProcessors();
		
		ExecutorService executorService = Executors.newFixedThreadPool(numberOfThreads);
		
		int subPartitionSize = 10000;
		
		int partitionSize = subPartitionSize * numberOfThreads;
		
		Writer writer = null;
		try {
			
			writer = new OutputStreamWriter(new BufferedOutputStream(new FileOutputStream(res), 1000000), CHARSET_NAME);
			
			if (partitionSize < halfSize) {
				partitionSize = halfSize;
			}
			
			int remaining = halfSize;
			int startIdx = 0;

			createPalindromeHalf(writer, executorService, remaining, startIdx, partitionSize, subPartitionSize, numberOfThreads, errorPositions);
			
			// if the size is an odd number, add a center character
			if (size % 2 > 0) {
				writer.append(CHARACTERS[0]);
			}
			
			remaining = halfSize;
			startIdx = halfSize-1;
			
			createPalindromeHalf(writer, executorService, remaining, startIdx, partitionSize, subPartitionSize, numberOfThreads, null);
			
		}
		finally {
			if (writer != null) {
				try {
					writer.close();
				}
				catch (Exception ex) {
					// ignore
				}
			}
			try {
				executorService.shutdown();
			}
			catch (Exception ex) {
				// ignore
			}
		}
		LOGGER.info("Test file created.");
		
		return res;
	}
	
	/**
	 * Creates one half of the test palindrome
	 * @param writer
	 * @param executorService
	 * @param remaining
	 * @param startIdx
	 * @param partitionSize
	 * @param subPartitionSize
	 * @param numberOfThreads
	 * @param errorPositions
	 * @throws Exception
	 */
	private void createPalindromeHalf(Writer writer, ExecutorService executorService, int remaining, int startIdx, int partitionSize, int subPartitionSize, int numberOfThreads, int[] errorPositions) throws Exception {
		int direction = startIdx == 0 ? 1 : -1;
		while (remaining > 0) {
			int currentPartitionSize = (remaining >= partitionSize ? partitionSize : remaining);
			int numberOfSubPartitions = (int)Math.ceil((double)currentPartitionSize / (double)subPartitionSize);
			int subRemaining = currentPartitionSize;
			List<PalindromeCreatorSlave> slaveList = new ArrayList<PalindromeCreatorSlave>();
			CountDownLatch latch = new CountDownLatch(Math.min(numberOfThreads, numberOfSubPartitions));
			int count = 0;
			while (subRemaining > 0) {
				if (count > 0 && count % numberOfThreads == 0) {
					latch.await();
					for (PalindromeCreatorSlave slave : slaveList) {
						writer.write(slave.getResult());
					}
					writer.flush();
					slaveList.clear();
					numberOfSubPartitions = numberOfSubPartitions - numberOfThreads;
					latch = new CountDownLatch(Math.min(numberOfThreads, numberOfSubPartitions));
				}
				int currentSubPartitionSize = (subRemaining >= subPartitionSize ? subPartitionSize : subRemaining);
				PalindromeCreatorSlave slave = new PalindromeCreatorSlave(startIdx, startIdx + (direction * currentSubPartitionSize), errorPositions, latch);
				slaveList.add(slave);
				executorService.execute(slave);
				startIdx = startIdx + (direction * currentSubPartitionSize);
				subRemaining = subRemaining - currentSubPartitionSize;
				count++;
			}
			remaining = remaining - currentPartitionSize;
			latch.await();
			for (PalindromeCreatorSlave slave : slaveList) {
				writer.write(slave.getResult());
			}
		}
		
	}
	

	/**
	 * Creating large palindromes took way to long, so I decided to use
	 * Master-Slave again for creation. :-)
	 */
	private class PalindromeCreatorSlave implements Runnable {


		final int fromIdx;
		
		final int toIdx;
		
		final int[] errorPositions;
		
		final CountDownLatch latch;
		
		char[] buffer;
		
		public PalindromeCreatorSlave(int fromIdx, int toIdx, int[] errorPositions, CountDownLatch latch) {
			this.fromIdx = fromIdx;
			this.toIdx = toIdx;
			this.errorPositions = errorPositions;
			this.latch = latch;
		}
		
		@Override
		public void run() {
			
			
			int len = Math.abs(toIdx - fromIdx);
			char[] buffer = new char[len];			
			
			int numberOfErrorPositions = (errorPositions == null ? 0 : errorPositions.length);
			int delta = 1;
			if (fromIdx > toIdx) {
				delta = -1;
			}
			
			for (int i = 0; i < len; i++) {
				int charIdx = fromIdx + (i * delta);
				if (numberOfErrorPositions > 0) {
					for (int j = 0; j < numberOfErrorPositions; j++) {
						if (charIdx == errorPositions[j]) {
							charIdx++;
							break;
						}
					}
				}
				charIdx = charIdx % NUMBER_OF_CHARACTERS;
				buffer[i] = CHARACTERS[charIdx];
			}
			synchronized(this) {
				this.buffer = buffer;
				latch.countDown();
			}
		}

		public char[] getResult() {
			synchronized(this) {
				return this.buffer;
			}
		}

	}
	
}
