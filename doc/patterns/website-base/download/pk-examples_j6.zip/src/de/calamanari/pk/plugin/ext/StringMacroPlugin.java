/*
 * String macro plugin 
 * Code-Beispiel zum Buch Patterns Kompakt, Spektrum Akademischer Verlag
 * Copyright 2012 Karl Eilebrecht
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package de.calamanari.pk.plugin.ext;

import java.util.Arrays;
import java.util.logging.Logger;

import de.calamanari.pk.plugin.MacroPlugin;
import de.calamanari.pk.plugin.MacroPluginFramework;

/**
 * String macro plugin allows string manipulation
 * @author <a href="mailto:Karl.Eilebrecht(a/t)freenet.de">Karl Eilebrecht</a>
 *
 */
public class StringMacroPlugin implements MacroPlugin {

	/**
	 * logger
	 */
	public static final Logger LOGGER = Logger.getLogger(StringMacroPlugin.class.getName());
	
	/**
	 * reference to the execution framework
	 */
	private MacroPluginFramework frameworkReference = null;
	
	/**
	 * Constructor
	 */
	public StringMacroPlugin() {
		LOGGER.fine(this.getClass().getSimpleName() + " created.");
	}
	
	
	@Override
	public String getName() {
		LOGGER.fine(this.getClass().getSimpleName() + ".getName() called.");
		return "String Macro Plugin";
	}

	@Override
	public String getVendor() {
		LOGGER.fine(this.getClass().getSimpleName() + ".getVendor() called.");
		return "Crap IT-Systems Inc.";
	}

	@Override
	public String getVersion() {
		LOGGER.fine(this.getClass().getSimpleName() + ".getVersion() called.");
		return "0.2";
	}

	@Override
	public String[] getMacros() {
		LOGGER.fine(this.getClass().getSimpleName() + ".getMacros() called.");
		return new String[]{"concat", "length", "reverse", "newString"}; 
	}

	@Override
	public void setFrameworkReference(MacroPluginFramework frameworkReference) {
		LOGGER.fine(this.getClass().getSimpleName() + ".setFrameworkReference() called.");
		this.frameworkReference = frameworkReference;
	}

	@Override
	public Object executeMacro(String macroName, Object[] args) {
		LOGGER.fine(this.getClass().getSimpleName() + ".executeMacro('" + macroName + "', ...) called.");		
		if (args == null) {
			frameworkReference.addProtocolMessage(this.getName() + "." + macroName, "args=null");
		}
		else {
			frameworkReference.addProtocolMessage(this.getName() + "." + macroName, "args=" + Arrays.asList(args));
		}
		if ("concat".equalsIgnoreCase(macroName)) {
			if (args == null || args.length < 2) {
				throw new RuntimeException("Could not execute macro '" + macroName + "' - insufficient arguments.");
			}
			StringBuilder sb = new StringBuilder();
			for (Object arg : args) {
				if ("\\n".equals(arg)) {
					sb.append("\n");
				}
				else {
					sb.append(arg);
				}
			}
			return sb.toString();
		}
		else if ("length".equals(macroName)) {
			if (args == null || args.length != 1) {
				throw new RuntimeException("Could not execute macro '" + macroName + "' - insufficient arguments.");
			}
			Object arg1 = args[0];
			if (!(arg1 instanceof String)) {
				throw new RuntimeException("Could not execute macro '" + macroName + "' - illegal argument (String expected).");
			}
			return new Integer(((String)arg1).length());
		}
		else if ("reverse".equals(macroName)) {
			if (args == null || args.length != 1) {
				throw new RuntimeException("Could not execute macro '" + macroName + "' - insufficient arguments.");
			}
			Object arg1 = args[0];
			if (arg1 == null) {
				return null;
			}
			if (!(arg1 instanceof String)) {
				throw new RuntimeException("Could not execute macro '" + macroName + "' - illegal argument (String expected).");
			}
			StringBuilder sb = new StringBuilder((String)arg1);
			sb.reverse();
			return sb.toString();
		}
		else if ("newString".equals(macroName)) {
			if (args == null || args.length != 1) {
				throw new RuntimeException("Could not execute macro '" + macroName + "' - insufficient arguments.");
			}
			Object arg1 = args[0];
			if (!(arg1 instanceof String)) {
				throw new RuntimeException("Could not execute macro '" + macroName + "' - illegal argument (String expected).");
			}
			return (String)arg1;
		}
		else {
			throw new RuntimeException("Could not execute macro '" + macroName + "' - unknown macro.");
		}
	}

}
