/*
 * Sequence block cache
 * Code-Beispiel zum Buch Patterns Kompakt, Spektrum Akademischer Verlag
 * Copyright 2012 Karl Eilebrecht
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package de.calamanari.pk.sequenceblock;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * The sequence block cache manages an arbitrary number of sequences using the
 * SEQUENCE BLOCK pattern.
 * @author <a href="mailto:Karl.Eilebrecht(a/t)freenet.de">Karl Eilebrecht</a>
 * 
 */
public class SequenceBlockCache {

	/**
	 * logger
	 */
	public static final Logger LOGGER = Logger.getLogger(SequenceBlockCache.class.getName());

	/**
	 * block size (number of keys to cache before accessing database table
	 * again)<br>
	 * <i>value:</i> {@value}
	 */
	public static final int DEFAULT_SEQUENCE_BLOCK_INCREMENT = 10;

	/**
	 * A global default instance
	 */
	public static final SequenceBlockCache GLOBAL_INSTANCE = new SequenceBlockCache();
	
	/**
	 * Since we want to show the pattern without a (transaction-aware)
	 * full-blown database we use a trick, see below.
	 */
	private static final Map<String, AtomicLong> simulatedDatabase = new ConcurrentHashMap<String, AtomicLong>();

	/**
	 * for internal synchronization
	 */
	private final Integer instanceLockObject = new Integer(0);

	/**
	 * Maps sequence names to sequence blocks
	 */
	private final Map<String, SequenceBlock> cachedSequenceBlocksMap = new ConcurrentHashMap<String, SequenceBlock>();

	/**
	 * Maps sequence names to the locks for synchronization
	 */
	private final Map<String, Integer> sequenceLockMap = new ConcurrentHashMap<String, Integer>();

	/**
	 * We want to do locking (synchronization) for single sequences only (not
	 * globally).<br>
	 * This method returns the Object we can synchronize on for the particular
	 * sequence.
	 * @param sequenceName name of sequence
	 * @return lock object for sychronization
	 */
	private Object getSequenceLockObject(String sequenceName) {
		Integer lockObject = sequenceLockMap.get(sequenceName);
		if (lockObject == null) {
			synchronized (instanceLockObject) {
				lockObject = sequenceLockMap.get(sequenceName);
				if (lockObject == null) {
					lockObject = new Integer(0);
					sequenceLockMap.put(sequenceName, lockObject);
				}
			}
		}
		return lockObject;
	}

	/**
	 * Returns the current item, rather for internal use, do NEVER modify/save !
	 * @param sequenceName (PK)
	 * @return current value of sequence or null to indicate a missing sequence
	 */
	private Long getCurrentSequenceNumberFromDb(String sequenceName) {
		LOGGER.fine(this.getClass().getSimpleName() + ".getCurrentSequenceNumberFromDb('" + sequenceName + "') called.");
		Long res = null;
		LOGGER.fine("Transaction.begin()");

		// START NEW TRANSACTION --->

		// usually you would ask the database by SQL
		// res = SqlManager.executeSelectLong(
		// dataSource,
		// "select SEQ_ID from SEQUENCE_TABLE where SEQ_NAME='" + sequenceName +
		// "'");

		// instead query simulated in-memory database
		res = doSimulatedSelect(sequenceName);

		// <--- END OF TRANSACTION
		LOGGER.fine("Transaction.commit()");

		return res;
	}

	/**
	 * Creates the new sequence and returns the current value of the sequence
	 * afterwards.
	 * @param sequenceName (PK)
	 * @return generic Value of type SequenceValueItem
	 */
	private Long createAndGetCurrentSequenceValue(String sequenceName) {
		LOGGER.fine(this.getClass().getSimpleName() + ".createAndGetCurrentSequenceValue('" + sequenceName + "') called.");

		// START NEW TRANSACTION --->
		LOGGER.fine("Transaction.begin()");

		try {
			// usually you would insert into the database by SQL
			// SqlManager.executeUpdate(
			// dataSource,
			// "insert into SEQUENCE_TABLE "
			// + "(SEQ_NAME, SEQ_ID) "
			// + "values ('" + sequenceName + "', 0)");

			// instead we use our in-memory-simulation
			doSimulatedInsert(sequenceName, 0);
		}
		catch (Exception ex) {
			// probably a race condition, silently ignored
			LOGGER.log(Level.WARNING, "Could not create new sequence record ('" + sequenceName + "').", ex);
		}

		// <--- END OF TRANSACTION
		LOGGER.fine("Transaction.commit()");

		// call other service to return the result of our insert or concurrent
		// insert
		return getCurrentSequenceNumberFromDb(sequenceName);
	}

	/**
	 * Returns a new sequence block or null if not successful (concurrent
	 * increment detected)
	 * @param sequenceName name of sequence in sequence table, MUST EXIST in
	 *            database at this time!
	 * @param lastUsedValue the last used key from that sequence
	 * @param blockIncrement optionally specify a block increment (number of
	 *            keys to be cached), equal or greater 1
	 * @return new sequence block or null to indicate that caller must try again
	 */
	private SequenceBlock reserveNextSequenceBlock(String sequenceName, long lastUsedValue, int blockIncrement) {
		LOGGER.fine(this.getClass().getSimpleName() + ".reserveNextSequenceBlock('" + sequenceName + "', lastUsedValue=" + lastUsedValue + ", blockIncrement=" + blockIncrement +") called.");
		
		SequenceBlock res = null;
		if (blockIncrement < 1) {
			blockIncrement = DEFAULT_SEQUENCE_BLOCK_INCREMENT;
		}
		long startOfBlock = lastUsedValue + 1;
		long endOfBlock = startOfBlock + blockIncrement;
		long updCount = 0;

		// START NEW TRANSACTION --->
		LOGGER.fine("Transaction.begin()");		
		// usually you would update the record in the database by SQL
		// updCount = SqlManager.executeUpdate(
		// dataSource,
		// "update SEQUENCE_TABLE "
		// + "set SEQ_ID=" + (endOfBlock-1)
		// + " where SEQ_NAME='" + sequenceName + "' and SEQ_ID=" +
		// lastUsedValue);

		// instead perform "update" on our simulated in-memory database table
		updCount = doSimulatedConditionalUpdate(sequenceName, lastUsedValue, (endOfBlock - 1));

		// <--- END OF TRANSACTION
		LOGGER.fine("Transaction.commit()");
		if (updCount == 1) {
			res = new SequenceBlock(startOfBlock, endOfBlock);
		}
		return res;
	}

	/**
	 * Returns the corresponding sequence block<br>
	 * @param sequenceName name of sequence in sequence table, missing sequences
	 *            will be auto-created
	 * @param blockIncrement optionally specify a block increment (number of
	 *            keys to be cached), equal or greater 1
	 * @return sequence block, never null (instead throws RuntimeException)
	 */
	private SequenceBlock getSequenceBlock(String sequenceName, int blockIncrement) {
		LOGGER.fine(this.getClass().getSimpleName() + ".getSequenceBlock('" + sequenceName + "', blockIncrement=" + blockIncrement +") called.");
		SequenceBlock sequenceBlock = cachedSequenceBlocksMap.get(sequenceName);
		if (sequenceBlock == null || sequenceBlock.isExhausted()) {
			// do not synchronize globally!
			synchronized (getSequenceLockObject(sequenceName)) { 
				LOGGER.fine("Performing lookup in sequence block cache");
				sequenceBlock = cachedSequenceBlocksMap.get(sequenceName);
				if (sequenceBlock == null || sequenceBlock.isExhausted()) {
					LOGGER.fine("Need new sequence block!");
					sequenceBlock = null;
					// retry strategy for concurrent access by multiple servers
					// get current state, try reserve, get current state, try
					// reserve ...
					// This retry-strategy could be improved :-)
					while (sequenceBlock == null) {
						Long currentValue = getCurrentSequenceNumberFromDb(sequenceName);
						if (currentValue == null) {
							// As many implementations we automatically create a
							// missing sequence, however this is
							// HIGHLY QUESTIONABLE since typos could lead to
							// heavy trouble ...
							LOGGER.info("Creating new sequence record for sequenceName='" + sequenceName + "'.");
							currentValue = createAndGetCurrentSequenceValue(sequenceName);
							if (currentValue == null) {
								throw new RuntimeException("The sequence '" + sequenceName + "' could neither be created nor updated (unknown server error).");
							}
						}
						long lastUsedValue = currentValue;
						if (lastUsedValue < 0) {
							throw new IllegalStateException("Found negative value for sequence '" + sequenceName + "' - check database SEQUENCE_TABLE!");
						}
						sequenceBlock = reserveNextSequenceBlock(sequenceName, currentValue, blockIncrement);
					}
					cachedSequenceBlocksMap.put(sequenceName, sequenceBlock);
				}
				else {
					LOGGER.fine("Found existing sequence block, no need for db-access.");
				}
			}
		}
		return sequenceBlock;
	}

	/**
	 * Returns the next available sequence id. Sequences start at 1.
	 * Non-existing sequences will be auto-created.
	 * @param sequenceName name of sequence in sequence table
	 * @param blockIncrement specify a block increment (number of keys to be
	 *            cached), equal or greater 1, less than 1 means default which
	 *            is {@link #DEFAULT_SEQUENCE_BLOCK_INCREMENT}
	 * @return sequence value as Long
	 */
	public long getNextId(String sequenceName, int blockIncrement) {
		LOGGER.fine(this.getClass().getSimpleName() + ".getNextId('" + sequenceName + "', blockIncrement=" + blockIncrement +") called.");
		if (blockIncrement < 1) {
			blockIncrement = DEFAULT_SEQUENCE_BLOCK_INCREMENT;
		}
		long res = -1;
		while (res < 0) {
			res = getSequenceBlock(sequenceName, blockIncrement).getNextId();
		}
		return res;
	}

	/**
	 * Returns the next available sequence id. Sequences start at 1.
	 * Non-existing sequences will be auto-created.<br>
	 * This convenience method uses the default block increment:
	 * {@link #DEFAULT_SEQUENCE_BLOCK_INCREMENT}
	 * @param sequenceName name of sequence in sequence table
	 * @return sequence value as Long
	 */
	public long getNextId(String sequenceName) {
		LOGGER.fine(this.getClass().getSimpleName() + ".getNextId('" + sequenceName + "') called.");
		return getNextId(sequenceName, DEFAULT_SEQUENCE_BLOCK_INCREMENT);
	}

	/**
	 * tries to insert a new record in our simulated sequence table
	 * @param sequenceName name of sequence
	 * @param value initial value
	 */
	private void doSimulatedInsert(String sequenceName, long value) {
		synchronized (SequenceBlockCache.class) {
			AtomicLong dbRecord = simulatedDatabase.get(sequenceName);
			if (dbRecord == null) {
				simulatedDatabase.put(sequenceName, new AtomicLong(value));
			}
			else {
				throw new RuntimeException("Record already exists.");
			}
		}
	}

	/**
	 * Reads the current sequence value from our simulated database table.
	 * @param sequenceName name of sequence
	 * @return current value
	 */
	private Long doSimulatedSelect(String sequenceName) {
		Long res = null;
		AtomicLong dbRecord = simulatedDatabase.get(sequenceName);
		if (dbRecord != null) {
			res = dbRecord.get();
		}
		return res;
	}

	/**
	 * Performs a conditional update on the simulated in-memory database table
	 * @param sequenceName name of sequence
	 * @param expectedValue old value
	 * @param newValue value to be set if expectedValue was found
	 * @return number of updated rows
	 */
	private long doSimulatedConditionalUpdate(String sequenceName, long expectedValue, long newValue) {
		long updCount = 0;
		AtomicLong dbRecord = simulatedDatabase.get(sequenceName);
		boolean success = dbRecord.compareAndSet(expectedValue, newValue);
		if (success) {
			updCount = 1;
		}
		return updCount;
	}

	
}
