/*
 * Customer Manager Server - a remote service handling persistence 
 * Code-Beispiel zum Buch Patterns Kompakt, Spektrum Akademischer Verlag
 * Copyright 2012 Karl Eilebrecht
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package de.calamanari.pk.datatransferobject.server;

import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import de.calamanari.pk.datatransferobject.Customer;
import de.calamanari.pk.datatransferobject.CustomerManager;
import de.calamanari.pk.util.AbstractConsoleServer;
import de.calamanari.pk.util.LogUtils;

/**
 * Customer Manager Server - a remote service handling persistence
 * @author <a href="mailto:Karl.Eilebrecht(a/t)freenet.de">Karl Eilebrecht</a>
 */
public class CustomerManagerServer extends AbstractConsoleServer implements CustomerManager {

	/**
	 * logger
	 */
	private static final Logger LOGGER = Logger.getLogger(CustomerManagerServer.class.getName());
	
	
	/**
	 * default registry port (our private server, usually this is 1099 for RMI!)
	 */
	public static final int DEFAULT_REGISTRY_PORT = 8091;
	
	/**
	 * port the RMI server listens
	 */
	private volatile int registryPort;
	
	/**
	 * server stub
	 */
	private volatile CustomerManager customerManagerStub;
	
	/**
	 * our private RMI-server
	 */
	private volatile Process rmiRegistryProcess;
	
	/**
	 * the manager's "database"
	 */
	private Map<String, CustomerEntity> database = new ConcurrentHashMap<String, CustomerEntity>();

	/**
	 * Creates new Customer Manager Server
	 */
	public CustomerManagerServer() {
		super(CustomerManagerServer.class.getSimpleName());
	}
	
	
	
	@Override
	public void addCustomer(String customerId, String lastName, String firstName, String street, String zipCode, String city) throws RemoteException {
		CustomerEntity entity = new CustomerEntity(customerId, lastName, firstName, street, zipCode, city);
		CustomerEntity entityExist = database.get(customerId);
		if (entityExist != null) {
			
			// without this, we would evtl. be unable to stop RMI later
			try {
				UnicastRemoteObject.unexportObject(entityExist, true);
			}
			catch (NoSuchObjectException ex) {
				// we can ignore that
			}
		}
		this.database.put(customerId, entity);
	}
	
	@Override
	public Customer findCustomer(String customerId) throws RemoteException {
		LOGGER.fine(this.getClass().getSimpleName() + ".findCustomer('" + customerId + "') called");
		return database.get(customerId);
	}

	@Override
	public Customer findCustomerReturnDto(String customerId) throws RemoteException {
		LOGGER.fine(this.getClass().getSimpleName() + ".findCustomerReturnDto('" + customerId + "') called");
		CustomerEntity entity = database.get(customerId);
		return (entity == null ? null : entity.toDto());
	}

	
	@Override
	protected void configureInstance(String[] cmdLineArgs) {
		
		if (cmdLineArgs != null && cmdLineArgs.length > 1 && "logfine".equalsIgnoreCase(cmdLineArgs[1])) {
			LogUtils.setConsoleHandlerLogLevel(Level.FINE);
			LogUtils.setLogLevel(Level.FINE, CustomerManagerServer.class);
		}
		else {
			LogUtils.setConsoleHandlerLogLevel(Level.INFO);
		}
		
		int port = DEFAULT_REGISTRY_PORT;
		if (cmdLineArgs != null && cmdLineArgs.length > 0) {
			try {
				port = Integer.parseInt(cmdLineArgs[0]);
			}
			catch (Exception ex) {
				LOGGER.log(Level.WARNING, "Error parsing rmi-port='" + cmdLineArgs[0] + "', using default=" + port, ex);
			}
		}
		this.registryPort = port;

		List<String> args = new ArrayList<String>();
		
		args.add("rmiregistry");
		args.add("" + port);
		
	    ProcessBuilder pb = new ProcessBuilder(args);
	    pb.environment().put("CLASSPATH", System.getProperties().getProperty("java.class.path", null));
	    try {
	    	LOGGER.info("Starting private RMI-Registry on port " + port + " ...");
	    	rmiRegistryProcess = pb.start();
	    	// give the registry some time to get ready
	    	Thread.sleep(3000);
	    	LOGGER.info("RMI-Registry ready.");
	    }
	    catch (Exception ex) {
	    	ex.printStackTrace();
	    	throw new RuntimeException(ex);
	    }
		
	}
	

	@Override
	protected void prepare() {
		try {
			this.customerManagerStub = (CustomerManager) UnicastRemoteObject.exportObject(this, 0);
            Registry registry = LocateRegistry.getRegistry(registryPort);
            registry.bind("CustomerManager", this.customerManagerStub);
		}
		catch (Exception ex) {
			LOGGER.log(Level.SEVERE, "Error during preparation!", ex);
		}
	}

	@Override
	protected String createStartupCompletedMessage() {
		return this.getServerName() + " started!";
	}

	@Override
	protected void doRequestProcessing() {
		while (true) {
			try {
				Thread.sleep(500);
			}
			catch (InterruptedException ex) {
				//ignore
			}
			if (getServerState() != ServerState.ONLINE) {
				break;
			}
		}
	}

	@Override
	protected void initiateShutdown() {
		// nothing to do
		
	}

	@Override
	protected void cleanUp() {
		try {
			if (this.customerManagerStub != null) {
	            Registry registry = LocateRegistry.getRegistry(registryPort);
	            registry.unbind("CustomerManager");
				UnicastRemoteObject.unexportObject(this, true);
				for (CustomerEntity entity : database.values()) {
					try {
						UnicastRemoteObject.unexportObject(entity, true);
					}
					catch (NoSuchObjectException ex) {
						// we can ignore that
					}
				}
			}
		}
		catch (Throwable t)  {
			LOGGER.log(Level.SEVERE, "Error during clean-up!", t);
		}
		try {
			if (rmiRegistryProcess != null) {
				rmiRegistryProcess.destroy();
				LOGGER.info("Private RMI-Registry stopped!");
			}
		}
		catch (Throwable t) {
			LOGGER.log(Level.SEVERE, "Error during RMI-shutdown!", t);
		}
	}
	
	/**
	 * Creates stand-alone console server
	 * @param args first argument may optionally specify the port
	 */
	public static void main( String args[] ) {
		(new CustomerManagerServer()).setupAndStart(args);
	}
	

}
