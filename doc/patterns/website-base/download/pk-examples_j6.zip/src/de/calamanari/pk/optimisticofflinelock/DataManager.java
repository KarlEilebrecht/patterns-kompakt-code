/*
 * Data Manager - handles persistence in this OPTIMISTIC OFFLINE LOCK example 
 * Code-Beispiel zum Buch Patterns Kompakt, Spektrum Akademischer Verlag
 * Copyright 2012 Karl Eilebrecht
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package de.calamanari.pk.optimisticofflinelock;

import java.util.ConcurrentModificationException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Logger;



/**
 * Data Manager - handles persistence in this OPTIMISTIC OFFLINE LOCK example<br>
 * Placeholder for any kind of database access management (i.e. DAO is compatible
 * with OPTIMISTIC OFFLINE LOCK pattern). 
 * @author <a href="mailto:Karl.Eilebrecht(a/t)freenet.de">Karl Eilebrecht</a>
 */
public class DataManager {

	/**
	 * logger
	 */
	protected static final Logger LOGGER = Logger.getLogger(DataManager.class.getName());	
	
	
	/**
	 * Simulates database
	 */
	private static ConcurrentHashMap<String, AtomicReference<String[]>> database = new ConcurrentHashMap<String, AtomicReference<String[]>>();
	
	
	/**
	 * Create a customer, in this example used to add test data
	 * @param customerId
	 * @param firstName
	 * @param lastName
	 * @param street
	 * @param zipCode
	 * @param city
	 */
	public static void addCustomer(String customerId, String firstName, String lastName, String street, String zipCode, String city) {
		database.put(customerId, new AtomicReference<String[]>(new String[]{customerId, firstName, lastName, street, zipCode, city, "0"}));
	}
	
	/**
	 * Returns the corresponding customer for the given id
	 * @param customerId
	 * @return Customer or null if not found 
	 */
	public static Customer findCustomerById(String customerId) {
		LOGGER.fine(Thread.currentThread().getName() + ": " + DataManager.class.getSimpleName() + ".findCustomerById('" + customerId + "') called");
		
		Customer res = null;
		
		LOGGER.fine(Thread.currentThread().getName() + ": " + "Performing transactional select on database ...");
		// begin TX
		
		//       select CUSTOMER_ID, 
		//              FIRST_NAME, 
		//              LAST_NAME, 
		//              STREET, 
		//              ZIPCODE, 
		//              CITY, 
		//              VERSION
		//       from CUSTOMERS
		//       where CUSTOMER_ID = ${customerId}

		res = doSimulateDbSelect(customerId);

		// end TX

		if (res != null) {
			LOGGER.fine(Thread.currentThread().getName() + ": " + "Found customer, record version: " + res.getVersion());
		}
		else {
			LOGGER.fine(Thread.currentThread().getName() + ": " + "Customer not found.");
		}
		return res;
	}
	
	/**
	 * Writes the customer data to the database (updates existing record).
	 * @param customer
	 */
	public static void storeCustomer(Customer customer) {
		LOGGER.fine(Thread.currentThread().getName() + ": " + DataManager.class.getSimpleName() + ".storeCustomer(" + customer + ") called");
		
		LOGGER.fine(Thread.currentThread().getName() + ": " + "Performing transactional update on database, expecting record version: " + customer.getVersion());
		// begin TX
		
		//       update CUSTOMERS
		//       set FIRST_NAME = ${firstName}
		//         , LAST_NAME  = ${lastName}
		//         , STREET     = ${street}
		//         , ZIPCODE    = ${zipCode}
		//         , CITY       = ${city}
		//         , VERSION    = VERSION + 1
		//       where CUSTOMER_ID = ${customerId}
		//         and VERSION  = ${version}     

		
		int numberOfUpdatedRecords = doSimulateDbUpdate(customer);
		
		// commit TX

		if (numberOfUpdatedRecords == 1) {
			customer.setVersion(customer.getVersion() + 1);
			LOGGER.fine(Thread.currentThread().getName() + ": " + "Database update successful, new record version: " + customer.getVersion());
		}
		else {
			Customer currentCustomerVersion = doSimulateDbSelect(customer.getCustomerId());
			if (currentCustomerVersion == null) {
				LOGGER.fine(Thread.currentThread().getName() + ": " + "Database update failed, record deletetion detected, throwing exception");
				throw new ConcurrentModificationException("Customer could not be updated: " + customer + " (deleted)");
			}
			else {
				LOGGER.fine(Thread.currentThread().getName() + ": " + "Database update failed, concurrent update detected (version mismatch, current version: " + currentCustomerVersion.getVersion() + ", expected: " + customer.getVersion() + "), throwing exception");
				throw new ConcurrentModificationException("Customer could not be updated: " + customer + " (version mismatch, current version: " + currentCustomerVersion.getVersion() + ", expected: " + customer.getVersion() + ")");
			}
			// The client may then decide to select the 
			// merge data - either automatically or with help of the user.
		}
	
	}
	
	
	
	/**
	 * Returns the corresponding customer for the given id
	 * @param customerId
	 * @return Customer or null if not found 
	 */
	private static Customer doSimulateDbSelect(String customerId) {
		Customer res = null;
		AtomicReference<String[]> record = database.get(customerId);
		String[] data = (record == null ? null : record.get());
		if (data != null) {
			res = new Customer(data[0], data[1], data[2], data[3], data[4], data[5]);
			try {
				res.setVersion(Long.parseLong(data[6]));
			}
			catch (Exception ex) {
				// won't happen here
				throw new RuntimeException(ex);
			}
		}
		return res;
	}
	
	/**
	 * Writes the customer data to the database (updates existing record).
	 * @param customer
	 * @return number of updated records
	 */
	private static int doSimulateDbUpdate(Customer customer) {
		
		int numberOfUpdatedRecords = 0;
		
		String sVersion = "" + customer.getVersion();
		
		AtomicReference<String[]> record = database.get(customer.getCustomerId());
		String[] data = (record == null ? null : record.get());
		if (data != null) {
			numberOfUpdatedRecords = 1;
			if (!data[6].equals(sVersion)) {
				numberOfUpdatedRecords = 0;
			}
			else {
				String[] newData = new String[]{customer.getCustomerId(), customer.getFirstName(), customer.getLastName(), customer.getStreet(), customer.getZipCode(), customer.getCity(), "" + (customer.getVersion() + 1)};
				boolean success = record.compareAndSet(data, newData);
				if (!success) {
					numberOfUpdatedRecords = 0;
				}
			}
		}
		return numberOfUpdatedRecords;
	}
	
	
}
