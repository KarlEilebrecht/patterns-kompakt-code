/*
 * Component Framework - supplementary class in DEPENDENCY INJECTION example
 * Code-Beispiel zum Buch Patterns Kompakt, Spektrum Akademischer Verlag
 * Copyright 2012 Karl Eilebrecht
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package de.calamanari.pk.dependencyinjection;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.logging.Logger;

/**
 * Component Framework - supplementary class in DEPENDENCY INJECTION example<br>
 * Allows the client to create a component, injects the necessary references
 * before handing over the component to the client.
 * @author <a href="mailto:Karl.Eilebrecht(a/t)freenet.de">Karl Eilebrecht</a>
 */
public class ComponentFramework {

	/**
	 * logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ComponentFramework.class.getName());
	
	
	/**
	 * constant in this example to obtain component 1
	 */
	public static final String COMPONENT_1 = "comp1";

	/**
	 * constant in this example to obtain component 2
	 */
	public static final String COMPONENT_2 = "comp2";
	
	/**
	 * constant in this example to obtain component 3
	 */
	public static final String COMPONENT_3 = "comp3";
	
	/**
	 * The framework's print service
	 */
	private static final PrintService thePrintService = new PrintServiceImpl();
	
	/**
	 * Creates the requested component and injects necessary services
	 * @param componentIdentifier identifies component type
	 * @return created component
	 * @throws Exception
	 */
	public static Component createComponent(String componentIdentifier) throws Exception {
		LOGGER.fine(ComponentFramework.class.getSimpleName() + ".createComponent(" + componentIdentifier + ") called");
		Component component = null;
		Class<? extends Component> componentClass = null;
		if (COMPONENT_1.equals(componentIdentifier)) {
			componentClass = ComponentWithConstructorInjection.class;
		}
		else if (COMPONENT_2.equals(componentIdentifier)) {
			componentClass = ComponentWithInterfaceInjection.class;
		}
		else if (COMPONENT_3.equals(componentIdentifier)) {
			componentClass = ComponentWithSetterInjection.class;
		}
		else {
			throw new IllegalArgumentException("No such component: " + componentIdentifier);
		}
		
		if (PrintServiceInjectable.class.isAssignableFrom(componentClass)) {
			LOGGER.fine("Found component class requesting interface injection ...");
			component = componentClass.newInstance();
			((PrintServiceInjectable)component).injectPrintService(thePrintService);
		}
		else {
			Constructor<? extends Component> constructor = getInjectionConstructor(componentClass);
			if (constructor != null) {
				LOGGER.fine("Found component class requesting constructor injection ...");
				component = constructor.newInstance(thePrintService);
			}
			else {
				Method method = getInjectionMethod(componentClass);
				if (method != null) {
					LOGGER.fine("Found component class requesting setter injection ...");
					component = componentClass.newInstance();
					method.invoke(component, thePrintService);
				}
				else {
					throw new IllegalArgumentException("Unable to inject reference into component: " + componentIdentifier + ", which was resolved to " + componentClass.getName());
				}
			}
		}
		return component;
	}
	
	/**
	 * Return an injection constructor for print service injection or null if no
	 * such constructor.
	 * @param cl class to be reflected
	 * @return appropriate constructor
	 */
	private static Constructor<? extends Component> getInjectionConstructor(Class<? extends Component> cl) {
		try {
			return cl.getConstructor(PrintService.class);
		}
		catch (Exception ex) {
			// ignore here
		}
		return null;
	}
	
	/**
	 * Return an injection method setPrintService() for print service injection or null if no
	 * such method.
	 * @param cl class to be reflected
	 * @return appropriate method
	 */
	private static Method getInjectionMethod(Class<?> cl) {
		try {
			return cl.getMethod("setPrintService", PrintService.class);
		}
		catch (Exception ex) {
			// ignore here
		}
		return null;
	}
	
	
}
