/*
 * Customer DTO - one of the data transfer objects in this example.
 * Code-Beispiel zum Buch Patterns Kompakt, Spektrum Akademischer Verlag
 * Copyright 2012 Karl Eilebrecht
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package de.calamanari.pk.transferobjectassembler;

import java.io.Serializable;
import java.util.logging.Logger;


/**
 * Customer DTO - one of the data transfer objects in this example.
 * @author <a href="mailto:Karl.Eilebrecht(a/t)freenet.de">Karl Eilebrecht</a>
 */
public class CustomerDto implements Serializable {

	/**
	 * logger
	 */
	protected static final Logger LOGGER = Logger.getLogger(CustomerDto.class.getName());	
	
	/**
	 * for serialization
	 */
	private static final long serialVersionUID = -7763516034748032756L;

	/**
	 * id of customer
	 */
	private String customerId = null;

	/**
	 * title field
	 */
	private String title = null;

	/**
	 * last name
	 */
	private String lastName = null;

	/**
	 * first name
	 */
	private String firstName = null;

	/**
	 * phone number
	 */
	private String phone = null;

	/**
	 * email address
	 */
	private String email = null;

	/**
	 * flag to indicate allowence for promotion activity
	 */
	private boolean promotionOptIn = false;

	// typically more attributes

	/**
	 * Creates new customer data transfer object
	 */
	public CustomerDto() {
		
	}
	
	/**
	 * Creates new data transfer object from the given data
	 * @param customerId
	 * @param title
	 * @param lastName
	 * @param firstName
	 * @param phone
	 * @param email
	 * @param promotionOptIn
	 */
	public CustomerDto(String customerId, String title, String lastName, String firstName, String phone, String email, boolean promotionOptIn) {
		this.customerId = customerId;
		this.title = title;
		this.lastName = lastName;
		this.firstName = firstName;
		this.phone = phone;
		this.email = email;
		this.promotionOptIn = promotionOptIn;
		LOGGER.fine(this.getClass().getSimpleName() + " created: " + this.toString());
	}

	/**
	 * Returns the customerId
	 * @return customerId
	 */
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * Sets the customerId
	 * @param customerId
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * Returns customer title
	 * @return title of customer
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Sets the customer's title
	 * @param title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * Returns the last name of customer
	 * @return lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Sets the customer's last name
	 * @param lastName
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Returns the customer's first name
	 * @return firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Sets the customer's first name
	 * @param firstName
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * Returns the customer's phone number
	 * @return phone
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * Sets the customer's phone number
	 * @param phone
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * Returns the customer's email address
	 * @return email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Sets the customer's email address
	 * @param email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Returns whether the customer has agreed to receive advertisement media
	 * @return true if customer has agreed, otherwise (default) false
	 */
	public boolean isPromotionOptIn() {
		return promotionOptIn;
	}

	/**
	 * Sets the customer's promotion status, whether to participate in sales
	 * promotion actions or not
	 * @param promotionOptIn true means the customer has agreed to receive
	 *            advertisement media
	 */
	public void setPromotionOptIn(boolean promotionOptIn) {
		this.promotionOptIn = promotionOptIn;
	}

	@Override
	public String toString() {
		return this.getClass().getSimpleName() + "({customerId=" + customerId + ", title=" + title + ", lastName=" + lastName + ", firstName=" + firstName
				+ ", phone=" + phone + ", email=" + email + ", promotionOptIn=" + promotionOptIn + "})";
	}
	
	
}
