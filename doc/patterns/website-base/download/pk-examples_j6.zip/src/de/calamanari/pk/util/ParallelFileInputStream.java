/*
 * Parallel File Input Stream
 * Code-Beispiel zum Buch Patterns Kompakt, Spektrum Akademischer Verlag
 * Copyright 2012 Karl Eilebrecht
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package de.calamanari.pk.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Logger;

/**
 * Parallel File Input Stream - input stream using a concurrent reader thread.<br>
 * This class is useful for reading large files especially if 
 * processing takes longer than reading. In this case the reader thread
 * can do a parallel read ahead while the main thread processes the
 * data from the last chunk and so on.<br>
 * Because the behavior of java NIO can differ from OS to OS
 * the caller can choose which buffer type to be used (see {@link BufferType}).<br>
 * <b>Note:</b><br>
 * <ul>
 * <li>For small files this technique is not recommended and may result in slow
 * processing.</li>
 * <li>Instances of ParallelFileInputStream MUST NOT be accessed concurrently.</li>
 * </ul>
 * @author <a href="mailto:Karl.Eilebrecht(a/t)freenet.de">Karl Eilebrecht</a>
 */
public class ParallelFileInputStream extends InputStream {

	
	/**
	 * logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ParallelFileInputStream.class.getName());
	
	
	/**
	 * Maximum buffer size, the default is {@value} bytes.
	 */
	public static final int DEFAULT_MAX_BUFFER_SIZE = 52428800;
	
	/**
	 * Internal variable storing the current maximum buffer size
	 */
	private final int maxBufferSize;
	
	/**
	 * configuration of the buffer type to be used
	 */
	private final BufferType bufferType;

	/**
	 * file size determined when opening the file
	 */
	private final long fileSize;
	
	
	/**
	 * the current buffer
	 */
	private ByteBuffer buffer = null;
	
	/**
	 * Number of bytes returned to a client
	 */
	private AtomicLong bytesDelivered = new AtomicLong(0L);

	/**
	 * The queue for communication from main thread to the reader
	 * The reader will not read a new buffer before being requested.
	 */
	private BlockingQueue<BufferEvent> bufferRequestQueue = new ArrayBlockingQueue<BufferEvent>(5);
	
	/**
	 * The queue for communication from reader thread to the main thread,
	 * the main thread waits for buffers delivered by the reader thread.
	 */
	private BlockingQueue<BufferEvent> bufferDeliveryQueue = new ArrayBlockingQueue<BufferEvent>(5);
	

	/**
	 * This is the file channel we work on, it is kept open during the life time
	 */
	private final FileChannel fileChannel;


	/**
	 * The position the reader has reached after the last call to a read method.
	 */
	private long position = 0;
	
	/**
	 * Separate reader thread
	 */
	private final ReaderThread readerThread;	
	
	/**
	 * We support the mark() operation, this stores the mark position relative
	 * to the current buffer. If the mark position is within the range of the
	 * current buffer, reset() is extremely cheap.
	 */
	private int markPositionRel = -1;
	
	/**
	 * We support the mark() operation for the whole file, if the mark position
	 * is outside the current buffer, we can reach it using an absolute
	 * repositioning to this memorized position.
	 */
	private long markPositionAbs = 0;
	
	
	/**
	 * container for single byte, an internal variable just for recycling
	 */
	private final byte[] singleByte = new byte[1];


	/**
	 * We store the last exception that occurred.
	 */
	private IOException readError = null;

	
	
	/**
	 * Creates a new Memory Mapped Parallel File Input Stream on the given file using
	 * the specified buffer size.<br>
	 * Note: A small buffer may lead to extremely bad performance!
	 * @param file underlying source file
	 * @param maxBufferSize maximum size a buffer may have (0 or less means {@link #DEFAULT_MAX_BUFFER_SIZE})
	 * @param bufferType the type of buffer to be used, see {@link BufferType}
	 * @return input stream
	 * @throws IOException
	 */
	public static ParallelFileInputStream createInputStream(File file, int maxBufferSize, BufferType bufferType) throws IOException {
		ParallelFileInputStream pfis = new ParallelFileInputStream(file, maxBufferSize, bufferType);
		pfis.readerThread.start();
		pfis.readNextPartitionParallel();
		return pfis;
	}
	
	/**
	 * Creates a new Memory Mapped Parallel File Input Stream on the given file using
	 * the specified buffer size. Uses memory mapped buffer (see {@link BufferType}).<br>
	 * Note: A small buffer may lead to extremely bad performance!
	 * @param file underlying source file
	 * @param maxBufferSize maximum size a buffer may have (0 or less means {@link #DEFAULT_MAX_BUFFER_SIZE})
	 * @return input stream
	 * @throws IOException
	 */
	public static ParallelFileInputStream createInputStream(File file, int maxBufferSize) throws IOException {
		return createInputStream(file, maxBufferSize, BufferType.MEMORY_MAPPED);
	}
	
	/**
	 * Creates a new Memory Mapped Parallel File Input Stream on the given file using
	 * default buffer size  ({@link #DEFAULT_MAX_BUFFER_SIZE}). Uses memory mapped buffer (see {@link BufferType}).
	 * @param file underlying source file
	 * @return input stream
	 * @throws IOException
	 */
	public static ParallelFileInputStream createInputStream(File file) throws IOException {
		return createInputStream(file, DEFAULT_MAX_BUFFER_SIZE);
	}
	
	/**
	 * Creates a new Memory Mapped Parallel File Input Stream on the given file using
	 * default buffer size  ({@link #DEFAULT_MAX_BUFFER_SIZE}).
	 * @param file underlying source file
	 * @param bufferType the type of buffer to be used, see {@link BufferType}
	 * @return input stream
	 * @throws IOException
	 */
	public static ParallelFileInputStream createInputStream(File file, BufferType bufferType) throws IOException {
		return createInputStream(file, DEFAULT_MAX_BUFFER_SIZE, bufferType);
	}
	
	/**
	 * Creates a new Memory Mapped Parallel File Input Stream on the given file using
	 * the specified buffer size.<br>
	 * Note: A small buffer may lead to extremely bad performance!
	 * @param fileName underlying source file's name
	 * @param maxBufferSize maximum size a buffer may have
	 * @param bufferType the type of buffer to be used, see {@link BufferType}
	 * @return input stream
	 * @throws IOException
	 */
	public static ParallelFileInputStream createInputStream(String fileName, int maxBufferSize, BufferType bufferType) throws IOException {
		return createInputStream(new File(fileName), maxBufferSize, bufferType);
	}
	
	/**
	 * Creates a new Memory Mapped Parallel File Input Stream on the given file using
	 * the specified buffer size. Uses memory mapped buffer (see {@link BufferType}).<br>
	 * Note: A small buffer may lead to extremely bad performance!
	 * @param fileName underlying source file's name
	 * @param maxBufferSize maximum size a buffer may have
	 * @return input stream
	 * @throws IOException
	 */
	public static ParallelFileInputStream createInputStream(String fileName, int maxBufferSize) throws IOException {
		return createInputStream(new File(fileName), maxBufferSize);
	}
	
	/**
	 * Creates a new Memory Mapped Parallel File Input Stream on the given file using
	 * default buffer size  ({@link #DEFAULT_MAX_BUFFER_SIZE}). Uses memory mapped buffer (see {@link BufferType}).
	 * @param fileName underlying source file's name
	 * @return input stream
	 * @throws IOException
	 */
	public static ParallelFileInputStream createInputStream(String fileName) throws IOException {
		return createInputStream(fileName, DEFAULT_MAX_BUFFER_SIZE);
	}

	/**
	 * Creates a new Memory Mapped Parallel File Input Stream on the given file using
	 * default buffer size  ({@link #DEFAULT_MAX_BUFFER_SIZE}).
	 * @param fileName underlying source file's name
	 * @param bufferType the type of buffer to be used, see {@link BufferType}
	 * @return input stream
	 * @throws IOException
	 */
	public static ParallelFileInputStream createInputStream(String fileName, BufferType bufferType) throws IOException {
		return createInputStream(fileName, DEFAULT_MAX_BUFFER_SIZE, bufferType);
	}
	
	
	/**
	 * Creates a new Memory Mapped Parallel File Input Stream on the given file using
	 * the specified buffer size.<br>
	 * Note: A small buffer may lead to extremely bad performance!
	 * @param file underlying source file
	 * @param maxBufferSize maximum size a buffer may have (0 or less means {@link #DEFAULT_MAX_BUFFER_SIZE})
	 * @param bufferType the type of buffer to be used, see {@link BufferType}
	 * @throws IOException
	 */
	private ParallelFileInputStream(File file, int maxBufferSize, BufferType bufferType) throws IOException {
		this.bufferType = bufferType;
		if (maxBufferSize <= 0) {
			maxBufferSize = DEFAULT_MAX_BUFFER_SIZE;
		}

		
		fileSize = file.length();
		if (maxBufferSize > fileSize) {
			maxBufferSize = (int)fileSize;
		}
		this.maxBufferSize = maxBufferSize;
		
		
		fileChannel = (new RandomAccessFile(file, "r")).getChannel();

		// tell the reader thread to fetch the first partition
		try {
			bufferRequestQueue.put(new BufferEvent());
		}
		catch (InterruptedException ex) {
			throw new IOException("Unexpected interruption during queue setup.", ex);
		}
		
		this.readerThread = new ReaderThread();
	}


	/**
	 * Returns the number of bytes that has been returned to the caller 
	 * during read()-operations until now.<br>
	 * This method does ignore skip() and mark(), so at the end of file the value 
	 * may be smaller than the file size or even greater.
	 * @return number of bytes delivered to the caller
	 */
	public long getNumberOfBytesDelivered() {
		return this.bytesDelivered.get();
	}
	
	/**
	 * Checks whether there was a read error and evtl. rethrows it
	 * @throws IOException
	 */
	private void assertNoError() throws IOException {
		if (this.readError != null) {
			throw this.readError;
		}
	}
	
	/**
	 * Checks whether there was a read error and evtl. rethrows it
	 * @param bufferEvent an event that could have an error
	 * @throws IOException
	 */
	private void assertNoError(BufferEvent bufferEvent) throws IOException {
		if (this.readError != null) {
			if (bufferEvent.eventType == BufferEventType.ERROR) {
				handleError(bufferEvent.error);
			}
		}
		assertNoError();
	}
	
	/**
	 * Take error, memorize it and rethrow IOException
	 * @param error
	 * @throws IOException
	 */
	private void handleError(Throwable error) throws IOException {
		if (this.readError != null) {
			if (error instanceof IOException) {
				this.readError = (IOException)error;
			}
			else {
				this.readError = new IOException(error);
			}
		}
		assertNoError();
	}
	
	/**
	 * Internal method to read the next partition.<br>
	 * Buffers will be switched and the reader will be triggered
	 * to fill the other buffer asynchronously.
	 * @throws IOException
	 */
	private void readNextPartitionParallel() throws IOException {
		markPositionRel = -1;
		try {
			if (readerThread == null) {
				throw new IllegalStateException("Reader thread unavailable - check code!");
			}

			assertNoError();
			
			
			BufferEvent bufferEvent = bufferDeliveryQueue.take();
			
			
			assertNoError(bufferEvent);
			
			ByteBuffer recycleBuffer = this.buffer;
			this.buffer = bufferEvent.buffer;
		
			bufferEvent.buffer = recycleBuffer;
			
			// now tell the reader to read next part of file
			// we can recycle event and the old buffer
			bufferEvent.eventType = BufferEventType.REQUEST_NEXT;
			bufferRequestQueue.put(bufferEvent);
			
		}
		catch (Throwable t) {
			handleError(t);
		}
	}
	
	
	
	@Override
	public int read(byte[] b) throws IOException {
		return this.read(b, 0, b.length);
	}

	@Override
	public int read(byte[] b, int off, int len) throws IOException {

		assertNoError();
		
		if (off + len > b.length) {
			throw new IndexOutOfBoundsException("The given byte[" + b.length + "]-array is too small to store " + len + " bytes starting at " + off + ".");
		}
		
		int lenReal = len;
		if (lenReal > fileSize - position) {
			lenReal = (int)(fileSize - position);
		}
		if (fileSize - position > 0) {
			if (buffer.remaining() < 1) {
				readNextPartitionParallel();
			}
			int lenTodo = lenReal;
			while (lenTodo > 0 && buffer.remaining() > 0) {
				int remaining = buffer.remaining();
				if (remaining > 0) {
					int lenPart = lenTodo;
					if (lenPart > remaining) {
						lenPart = remaining; 
					}
					lenTodo = lenTodo - lenPart;
					buffer.get(b, off, lenPart);
					off = off + lenPart;
					position = position + lenPart;
				}
				if (lenTodo > 0) {
					readNextPartitionParallel();
				}
			}
			lenReal = lenReal - lenTodo;
		}
		if (lenReal > 0) {
			bytesDelivered.addAndGet(lenReal);
			return lenReal;
		}
		else {
			return -1;
		}
	}

	
	
	/**
	 * Repositions the pointer on the stream so that the next
	 * buffer access will read at the given absolute position<br>
	 * If this given position is greater file size, 
	 * the pointer will be set at the end of file.
	 * @param positionAbs absolute position in file (if greater than file size, we will reposition at EOF)
	 */
	public void repositionFileStream(long positionAbs) throws IOException {

		assertNoError();
		
		markPositionRel = -1;
		
		if (positionAbs > fileSize) {
			positionAbs = fileSize;
		}
		
		BufferEvent bufferRequest = new BufferEvent();
		bufferRequest.eventType = BufferEventType.REQUEST_REPOSITION;
		bufferRequest.startPositionAbs = positionAbs;
		bufferRequest.buffer = this.buffer;
		try {
			bufferRequestQueue.put(bufferRequest);
		}
		catch (InterruptedException ex) {
			handleError(ex);
		}
		
		
		BufferEvent answer = null;
		boolean done = false;
		do {
			try {
				answer = bufferDeliveryQueue.take();
			}
			catch (InterruptedException ex) {
				handleError(ex);
			}
			if (answer.eventType == BufferEventType.DELIVER_BUFFER 
					&& answer.repositionAnswer) {
				//this is the one we requested
				done = true;
			}
			else if (answer.eventType == BufferEventType.DELIVER_BUFFER) {
				// this is a part of file that was read BEFORE the repositioning
				// happened (useless data)
				// recycle the buffer by requesting the next part
				bufferRequest = answer;
				bufferRequest.eventType = BufferEventType.REQUEST_NEXT;
				try {
					bufferRequestQueue.put(bufferRequest);
				}
				catch (InterruptedException ex) {
					handleError(ex);
				}
			}
			else {
				done = true; //must be an error
			}
		}
		while (!done);
		
		assertNoError(answer);

		this.buffer = answer.buffer;
		position = positionAbs;
	}
	
	@Override
	public long skip(long bytesToBeSkipped) throws IOException {

		assertNoError();
		

		if (position + bytesToBeSkipped > fileSize) {
			bytesToBeSkipped = fileSize - position;
		}
		position = position + bytesToBeSkipped;
		
		long leftBytesToBeSkipped = bytesToBeSkipped;
		long remaining = buffer.remaining();
		if (remaining < bytesToBeSkipped) {
			leftBytesToBeSkipped = bytesToBeSkipped - remaining;
			if (leftBytesToBeSkipped > maxBufferSize) {
				repositionFileStream(position);
				leftBytesToBeSkipped = 0;
			}
			else {
				readNextPartitionParallel();
			}
		}
		buffer.position(buffer.position() + (int)leftBytesToBeSkipped);
		
		return bytesToBeSkipped;
	}

	@Override
	public int available() throws IOException {
		return buffer.remaining();
	}

	@Override
	public void close() throws IOException {

		try {
			readerThread.reading = false;
		}
		catch (Throwable t) {
			//ignore
		}

		try {
			BufferEvent bufferEvent = new BufferEvent();
			bufferEvent.eventType = BufferEventType.SHUTDOWN;
			bufferRequestQueue.put(bufferEvent);
		}
		catch (Throwable t) {
			// try it by interrupt
			readerThread.interrupt();
		}
		
		fileChannel.close();
		
		this.buffer = ByteBuffer.allocate(0);
		System.gc();
		
		// What the hell ... ?! 
		// The two lines above may seem a little esoteric, 
		// but they help to release files on windows.
		// I think this is a problem with memory mapped IO (buffer).
		// As long as the mapping is active, a file cannot
		// be deleted/renamed etc.
		//
		// The line
		//     this.buffer = ByteBuffer.allocate(0);
		//
		// removes the strong reference to the old buffer
		// which (in principle) allows garbage collection.
		// I don't use null but an empty buffer because this
		// is more robust, I don't have to cope with
		// null-handling all over the code.
		//
		// The other line
		//     System.gc();
		//
		// causes a hint to garbage collection.
		// However, this does not force the file release but it
		// highly increases the chance ...
		
	}

	@Override
	public void mark(int readlimit) {
		this.markPositionAbs = position;
		this.markPositionRel = buffer.position();
	}

	@Override
	public void reset() throws IOException {

		assertNoError();
		
		if (markPositionRel > -1) {
			position = markPositionAbs;
			buffer.position(markPositionRel);
			markPositionRel = -1;
		}
		else {
			repositionFileStream(markPositionAbs);
		}
	}

	/**
	 * Mark is supported.
	 */
	@Override
	public boolean markSupported() {
		return true;
	}

	@Override
	public int read() throws IOException {
		int res = read(singleByte, 0, 1);
		if (res < 0) {
			return -1;
		}
		else {
			return singleByte[0];
		}
	}
	

	
	
	@Override
	protected void finalize() throws Throwable {
		try {
			this.close();
		}
		finally {
			super.finalize();
		}
	}



	/**
	 * The reader thread reads the stream concurrently to the main thread.<br>
	 * This is achieved by switching buffers. While one buffer is in 
	 * use (consumer reads) the other one can be filled. 
	 */
	private final class ReaderThread extends Thread {
			
		/**
		 * where to read next part of file
		 */
		private long startNextPartition = 0;

		/**
		 * flag to indicate reader is enabled
		 */
		private volatile boolean reading = true;
		
		/**
		 * Creates new reader thread without starting it, yet.
		 */
		public ReaderThread() {
			this.setDaemon(true);
		}
		
	
		public void run() {
			try {
				while (reading) {
					
					BufferEvent bufferEvent = bufferRequestQueue.take();
					
					if (bufferEvent.eventType == BufferEventType.REQUEST_NEXT 
							|| bufferEvent.eventType == BufferEventType.REQUEST_REPOSITION) {
						

						// set position if requested and prepare answer
						if (bufferEvent.eventType == BufferEventType.REQUEST_REPOSITION) {
							this.startNextPartition = bufferEvent.startPositionAbs;
							bufferEvent.repositionAnswer = true;
						}
						bufferEvent.eventType = BufferEventType.DELIVER_BUFFER;
						
						long bufferSize = maxBufferSize;

						if (startNextPartition + bufferSize > fileSize) {
							bufferSize = fileSize - startNextPartition;
						}
						if (bufferSize > 0) {
							if (bufferType == BufferType.MEMORY_MAPPED)  {
								bufferEvent.buffer = fileChannel.map(FileChannel.MapMode.READ_ONLY, startNextPartition, bufferSize);
								((MappedByteBuffer)bufferEvent.buffer).load();
							}
							else {
								fileChannel.position(startNextPartition);
								if (bufferEvent.buffer == null) {
									if (bufferType == BufferType.DIRECT) {
										bufferEvent.buffer = ByteBuffer.allocateDirect(maxBufferSize);
									}
									else {
										bufferEvent.buffer = ByteBuffer.allocate(maxBufferSize);									
									}
								}
								else {
									bufferEvent.buffer.clear();
								}
								ByteBuffer[] buffers = new ByteBuffer[]{bufferEvent.buffer};
								
								fileChannel.read(buffers, 0, 1);
								bufferEvent.buffer.rewind();
								
							}
							startNextPartition = startNextPartition + bufferSize;
						}
						else {
							if (bufferType == BufferType.MEMORY_MAPPED)  {
								bufferEvent.buffer = ByteBuffer.allocate(0);
							}
							else {
								if (bufferEvent.buffer == null) {
									if (bufferType == BufferType.DIRECT) {
										bufferEvent.buffer = ByteBuffer.allocateDirect(maxBufferSize);
									}
									else {
										bufferEvent.buffer = ByteBuffer.allocate(maxBufferSize);									
									}
								}
								else {
									bufferEvent.buffer.clear();
								}
							}
						}
						
						bufferDeliveryQueue.put(bufferEvent);
						
					}
					else if (bufferEvent.eventType == BufferEventType.SHUTDOWN) {
						break;
					}
					else {
						throw new IllegalStateException("Unexpected buffer event " + bufferEvent.eventType);
					}
				}
			}
			catch (Throwable t) {
				BufferEvent bufferEvent = new BufferEvent();
				bufferEvent.eventType = BufferEventType.ERROR;
				bufferEvent.error = t;
				try {
					t.printStackTrace();
					bufferDeliveryQueue.put(bufferEvent);
				}
				catch (Throwable ex) {
					// this is extremely fatal, hope this will never happen
					LOGGER.severe("Unexpected error during critical queue operation, maybe consumer hangs now.");
				}
			}
			finally {
				try {
					fileChannel.close();
				}
				catch (Throwable t) {
					// ignore
				}
			}
		}
	}

	/**
	 * BufferEvents are for communication between reader thread
	 * and main thread and vice-versa. 
	 */
	private static class BufferEvent {
		
		
		/**
		 * identifies the type of this event
		 */
		public BufferEventType eventType = BufferEventType.REQUEST_NEXT;
		
		/**
		 * new start position for repositioning (absolute file position)
		 */
		public long startPositionAbs = 0L;
		
		/**
		 * a reference to a buffer. <br> 
		 * The Reader sends a filled buffer to the
		 * main thread. <br>
		 * The main thread may use this attribute to return 
		 * an existing buffer for recycling.
		 */
		public ByteBuffer buffer = null;
		
		/**
		 * The reader will indicate this when delivering the first
		 * buffer after having repositioned the stream.
		 */
		public boolean repositionAnswer = false;

		/**
		 * if this is an error event, this is the exception that
		 * occurred while reading
		 */
		public Throwable error = null;
		
	}

	/**
	 * The BufferEventType identifies the type of event in one of the
	 * queues for communication between main thread and reader thread
	 */
	private enum BufferEventType {
		
		/**
		 * the reader shall provide the next part of the file,
		 * starting at the position the last part ended
		 */
		REQUEST_NEXT, 
		
		/**
		 * The reader shall reposition, the position can be obtained from
		 * the event's properties
		 */
		REQUEST_REPOSITION, 
		
		/**
		 * The reader shall stop reading and close resources
		 */
		SHUTDOWN, 
		
		/**
		 * The reader has provided another part of the file, the corresponding
		 * buffer is attached.
		 */
		DELIVER_BUFFER, 

		/**
		 * The reader got an error and has closed resources.
		 */
		ERROR
		
	}
	
	
	/**
	 * Three types of buffers are supported.  
	 */
	public enum BufferType {
		
		/**
		 * Typical byte buffer<br>
		 * <b>Caution:</b> The buffer will reside on the VM-heap.
		 */
		NON_DIRECT, 
		
		/**
		 * Direct byte buffer<br>
		 * Typically direct buffers do reside outside normal VM-heap, but
		 * (implementation dependent) may reside inside.
		 */
		DIRECT, 
		
		/**
		 * A MemoryMappedByteBuffer reside outside the normal VM-heap,
		 * this is the recommended type for high performance reading.
		 */
		MEMORY_MAPPED
	}

	
	
	
}
