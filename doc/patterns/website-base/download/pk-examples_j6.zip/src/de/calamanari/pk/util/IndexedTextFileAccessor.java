/*
 * Indexed Text File Accessor 
 * Code-Beispiel zum Buch Patterns Kompakt, Spektrum Akademischer Verlag
 * Copyright 2012 Karl Eilebrecht
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package de.calamanari.pk.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.io.Reader;
import java.io.Serializable;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.util.Arrays;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Indexed Text File Accessor creates an index for a given file and allows 
 * to jump to specific characters or lines.<br>
 * This is intended for reading large text files which won't be modified after
 * index creation.<br>
 * An instance is safe to be used by multiple threads.
 * @author <a href="mailto:Karl.Eilebrecht(a/t)freenet.de">Karl Eilebrecht</a>
 */
public class IndexedTextFileAccessor {

	/**
	 * Default configuration (not public because configurations are mutable)
	 */
	private static final Configuration DEFAULT_CONFIGURATION = new Configuration();
	
	/**
	 * We need to know the length in bytes per character, here we cache index table for fast lookup
	 */
	private static final Map<String, byte[]> CHAR_LENGTH_LOOKUP_REGISTRY = new ConcurrentHashMap<String, byte[]>(); 

	/**
	 * character code for line break
	 */
	private static final int LINE_BREAK_CODE = (int)'\n';
	
	/**
	 * character code for carriage return
	 */
	private static final int CARRIAGE_RETURN_CODE = (int)'\r';
	
	/**
	 * Stores the mapping character position to file position
	 */
	private final Map<Long, Long> characterPositionIndex;

	/**
	 * Stores the mapping line position to file position
	 */
	private final Map<Long, Long> linePositionIndex;
	
	/**
	 * size of the indexed file
	 */
	private final long fileSize;
	

	/**
	 * number of entries in the character position index
	 */
	private final int numberOfCharacterIndexEntries;

	/**
	 * number of entries in the line position index
	 */
	private final int numberOfLineIndexEntries;
	
	/**
	 * Number of lines in file
	 */
	private final long numberOfLines;
	
	/**
	 * sorted array of indexed line numbers in index
	 */
	private final long[] indexedLineNumbers;

	/**
	 * sorted array of indexed character numbers in index
	 */
	private final long[] indexedCharNumbers;
	
	/**
	 * Number of characters in file
	 */
	private final long numberOfCharacters;
	

	/**
	 * The file the indexed file belongs to
	 */
	private final File sourceFile;
	
	/**
	 * name of the charset used to read the file
	 */
	private final String charsetName;
	
	/**
	 * To enable users of this instance to get the physical byte position the
	 * last managed position is stored here.
	 */
	private final ThreadLocal<Long> lastKnownFilePosition = new ThreadLocal<Long>();
	
	/**
     * Buffer size in bytes for readers returned by the textfile accessor.
	 */
	private final int defaultChildReaderBufferSize;

	/**
	 * A lookup for all character codes to the length (in bytes) of the character represented using
	 * the current charset.
	 */
	private final byte[] charLengthLookup;
	
	/**
	 * Helper method to create configuration
	 * @param maxNumberOfCharIndexEntries maximum number of entries in the character index
	 * @param maxNumberOfLineIndexEntries maximum number of entries in the line index
	 * @param bomSize number of inital bytes to be skipped
	 * @return new default configuration with the given changes applied
	 */
	private static Configuration createConfiguration(int maxNumberOfCharIndexEntries, int maxNumberOfLineIndexEntries, int bomSize) {
		Configuration res = new Configuration();
		res.bomSize = bomSize;
		res.maxNumberOfCharIndexEntries = maxNumberOfCharIndexEntries;
		res.maxNumberOfLineIndexEntries = maxNumberOfLineIndexEntries;
		return res;
	}
	
	/**
	 * Creates new IndexedTextFileAccessor of default size <br>
	 * see {@link #IndexedTextFileAccessor(File, String, Configuration)}, {@link #DEFAULT_CONFIGURATION}
	 * @param file readable file
	 * @param charsetName name of character set
	 */
	public IndexedTextFileAccessor(File file, String charsetName) throws IOException {
		this(file, charsetName, null);
	}
	
	/**
	 * Creates new IndexedTextFileAccessor, this opens the file followed by an index run, 
	 * does NOT keep the file open.<br>
	 * By specifying the maximum number of index entries the caller has some control over the memory
	 * consumption. One entry consists of 3 Longs accompanied by some overhead.<br>
	 * This implementation does not support charset auto-detection but can ignore byte order mark by
	 * skipping a specified number of bytes. However, the job to decide whether or not there is
	 * a byte order mark is up to the caller, see also: http://bugs.sun.com/view_bug.do?bug_id=4508058
	 * @param file readable file
	 * @param charsetName name of character set
	 * @param maxNumberOfCharIndexEntries maximum number of index entries for characters (min=1)
	 * @param maxNumberOfLineIndexEntries maximum number of index entries for lines (min=1)
	 * @param bomSize number of bytes to be skipped
	 */
	public IndexedTextFileAccessor(File file, String charsetName, int maxNumberOfCharIndexEntries, int maxNumberOfLineIndexEntries, int bomSize) throws IOException {
		this(file, charsetName, createConfiguration(maxNumberOfCharIndexEntries, maxNumberOfLineIndexEntries, bomSize));
	}
	
	/**
	 * Creates new IndexedTextFileAccessor, this opens the file followed by an index run, 
	 * does NOT keep the file open.<br>
	 * @param file readable file
	 * @param charsetName name of character set
	 * @param configuration indexer settings, null means default
	 */
	public IndexedTextFileAccessor(File file, String charsetName, Configuration configuration) throws IOException {
		
		// This constructor is way too long. Ahem ... maybe I should refactor it ... :-)
		
		
		if (configuration == null) {
			configuration = DEFAULT_CONFIGURATION;
		}
		
		this.charLengthLookup = createCharLengthLookup(charsetName);
		
		this.defaultChildReaderBufferSize = configuration.childReaderBufferSize;
		
		if (configuration.maxNumberOfCharIndexEntries < 1) {
			throw new IllegalArgumentException("Argument maxNumberOfCharIndexEntries=" + configuration.maxNumberOfCharIndexEntries + " is too small.");
		}

		if (configuration.maxNumberOfLineIndexEntries < 1) {
			throw new IllegalArgumentException("Argument maxNumberOfLineIndexEntries=" + configuration.maxNumberOfLineIndexEntries + " is too small.");
		}
		
		if (configuration.bomSize < 0)  {
			throw new IllegalArgumentException("Argument bomSize must not be negative, given: " + configuration.bomSize);
		}
		
		if (defaultChildReaderBufferSize < 0) {
			throw new IllegalArgumentException("Argument childReaderBufferSize must not be negative, given: " + configuration.childReaderBufferSize);
		}
		
		fileSize = file.length();
		long dataSize = fileSize - configuration.bomSize;
		
		// the character entry distance: each n bytes there should be a character index entry
		long averageCharEntryDistance = (long)Math.ceil(((double)dataSize) / configuration.maxNumberOfCharIndexEntries);
		if (averageCharEntryDistance == 0) {
			averageCharEntryDistance = 1;
		}

		// the line entry distance: each n bytes there may be a line index entry
		long averageLineEntryDistance = (long)Math.ceil(((double)dataSize) / configuration.maxNumberOfLineIndexEntries);
		if (averageLineEntryDistance == 0) {
			averageLineEntryDistance = 1;
		}
		
		
		// for a number of characters (number of character in the sequence) map the exact byte position
		Map<Long, Long> characterPositionIndex = new ConcurrentHashMap<Long, Long>();		

		// for a number of lines map the exact byte position of the first character
		Map<Long, Long> linePositionIndex = new ConcurrentHashMap<Long, Long>();

		ParallelFileInputStream is = null;
		BufferedReader br = null;
		char[] buffer = new char[configuration.charBufferSize];

		long totalNumberOfBytesProcessed = 0L;
		long totalNumberOfCharsRead = 0L;
		long totalNumberOfLinesRead = 0L;
		
		
		ExecutorService executorService = null;
		try {
			sourceFile = file;
			
			is = ParallelFileInputStream.createInputStream(file, configuration.indexerReadBufferSize, configuration.indexerReadBufferType);
			for (int i = 0; i < configuration.bomSize; i++) {
				is.read();
			}

			// number of Bytes processed, yet
			// this allows us to determine the position within the file
			long lastNumberOfBytesProcessed = is.getNumberOfBytesDelivered();

			
			br = new BufferedReader(new InputStreamReader(is, charsetName), configuration.charBufferSize);
			
			long currentBytePos = (configuration.bomSize > 0) ? configuration.bomSize : 0L;
			if (dataSize > 0)  {
				characterPositionIndex.put(0L, currentBytePos);
				linePositionIndex.put(0L, currentBytePos);
			}
			
			int numberOfThreads = Runtime.getRuntime().availableProcessors();
			
			if (dataSize < configuration.multiThreadingThreshold) {
				numberOfThreads = 1;
			}

			// master uses a number of slaves
			executorService = Executors.newFixedThreadPool(numberOfThreads);
			
			IndexerSlave[] indexerSlaves = new IndexerSlave[numberOfThreads];

			for (int i = 0; i < numberOfThreads; i++) {
				indexerSlaves[i] = new IndexerSlave(this.charLengthLookup);
			}
			
			int partitionSize = 0;
			
			// handling line breaks is complex, we avoid carriage returns at the end of a partition
			// because there may be a following line feed
			// thus we move a trailing CR to the next partition
			// in this case the buffer start index will be 1 otherwise 0
			boolean movedCR = false;
			int bufferStartIdx = 0;

			
			// distributing the entries over the file needs corrections to avoid loosing possible
			// entries (division/remainder problem)
			// To reduce loss the delta helps us collecting "entry fractions"
			double charEntryDelta = 0;
			double lineEntryDelta = 0;
			
			// On the other hand entries may be lost in sub partitions
			// these entries will be counted added to the next partition run
			int lostCharEntries = 0;
			int lostLineEntries = 0;
			
			while ((partitionSize = br.read(buffer, bufferStartIdx, configuration.charBufferSize - bufferStartIdx)) != -1 || bufferStartIdx > 0)  {
				
				if (partitionSize == -1) {
					partitionSize = bufferStartIdx;
				}
				
				long numberOfBytesProcessed = is.getNumberOfBytesDelivered();
				
				long partitionSizeInBytes = numberOfBytesProcessed - lastNumberOfBytesProcessed;
				
				// re-integrate moved carriage return
				if (movedCR) {
					partitionSizeInBytes = partitionSizeInBytes + charLengthLookup[(int)CARRIAGE_RETURN_CODE];
				}
				
				// check this partition whether it ends with a CR
				movedCR = (partitionSize > 1 && buffer[partitionSize-1] == CARRIAGE_RETURN_CODE);
				
				// move CR to next partition
				if (movedCR) {
					partitionSize--;
					partitionSizeInBytes = partitionSizeInBytes - charLengthLookup[(int)CARRIAGE_RETURN_CODE];
				}
				
				// calculate number of entries and loss
				double exactMaxNumberOfCharEntriesInPartition = ((double)partitionSizeInBytes / (double)averageCharEntryDistance) + lostCharEntries;
				int maxNumberOfCharEntriesInPartition = ((int)(Math.floor(exactMaxNumberOfCharEntriesInPartition)));
				charEntryDelta = charEntryDelta + (exactMaxNumberOfCharEntriesInPartition - maxNumberOfCharEntriesInPartition);

				double exactMaxNumberOfLineEntriesInPartition = ((double)partitionSizeInBytes / (double)averageLineEntryDistance) + lostLineEntries;
				int maxNumberOfLineEntriesInPartition = ((int)(Math.floor(exactMaxNumberOfLineEntriesInPartition)));
				lineEntryDelta = lineEntryDelta + (exactMaxNumberOfLineEntriesInPartition - maxNumberOfLineEntriesInPartition);
				

				lostCharEntries = 0;
				lostLineEntries = 0;
				
				lastNumberOfBytesProcessed = numberOfBytesProcessed;
				
				int numberOfSlaves = 1;
				int minSubPartitionSize = partitionSize;
				
				if (partitionSize > configuration.multiThreadingThreshold) {
					minSubPartitionSize = partitionSize / numberOfThreads;
					numberOfSlaves = numberOfThreads;
				}

				// a latch to let the slaves communicate with the master
				CountDownLatch latch = new CountDownLatch(numberOfSlaves);

				// in the code below we calculate how many entries we have to spread over the partition and its sub-partitions
				
				double exactMaxNumberOfCharEntriesInSubPartition = (double)maxNumberOfCharEntriesInPartition / (double)numberOfSlaves;
				
				int maxNumberOfCharEntriesInSubPartition = (int)Math.floor(exactMaxNumberOfCharEntriesInSubPartition);
				charEntryDelta = charEntryDelta + (exactMaxNumberOfCharEntriesInSubPartition - maxNumberOfCharEntriesInSubPartition) * numberOfSlaves;

				if (charEntryDelta > numberOfSlaves) {
					maxNumberOfCharEntriesInSubPartition++;
					charEntryDelta = charEntryDelta - numberOfSlaves;
				}

				double exactMaxNumberOfLineEntriesInSubPartition = (double)maxNumberOfLineEntriesInPartition / (double)numberOfSlaves;
				int maxNumberOfLineEntriesInSubPartition = (int)Math.floor(exactMaxNumberOfLineEntriesInSubPartition);
				lineEntryDelta = lineEntryDelta + (exactMaxNumberOfLineEntriesInSubPartition - maxNumberOfLineEntriesInSubPartition) * numberOfSlaves;
				
				if (lineEntryDelta > numberOfSlaves) {
					maxNumberOfLineEntriesInSubPartition++;
					lineEntryDelta = lineEntryDelta - numberOfSlaves;
				}
				
				boolean subPartitionMovedCR = false;

				// now setup and start slaves
				for (int i = 0; i < numberOfSlaves; i++) {
					int subPartitionStartIdx = i * minSubPartitionSize;

					int subPartitionSize = minSubPartitionSize;
					
					
					// Within sub-partitions we also have to deal with trailing 
					// carriage returns (move to the next sub-partition)
					
					if (subPartitionMovedCR) {

						// found "saved" carriage return, prepend to current sub-partition
						subPartitionStartIdx--;

						// adopt partition size
						subPartitionSize++;
					}
					
					// shall we move a trailing carriage return?
					subPartitionMovedCR = (i < (numberOfSlaves - 1) && buffer[subPartitionStartIdx + subPartitionSize-1] == CARRIAGE_RETURN_CODE);
					
					if (subPartitionMovedCR) {
						// move carriage return to next sub-partition by (truncate)
						subPartitionSize--;
					}
					
					if (i == numberOfSlaves - 1) {
						// special case: last sub-partition, process ALL remaining characters
						subPartitionSize = partitionSize - subPartitionStartIdx;
					}
					
					IndexerSlave slave = indexerSlaves[i];
					slave.latch = latch;
					slave.maxNumberOfCharEntries = maxNumberOfCharEntriesInSubPartition;
					slave.maxNumberOfLineEntries = maxNumberOfLineEntriesInSubPartition;
					slave.partition = buffer;
					slave.startIdx = subPartitionStartIdx;
					slave.subPartitionSize = subPartitionSize;
					slave.propagateError.set(null);
					slave.result.set(null);
					executorService.execute(slave);
				}

				// wait for the slaves to complete
				try {
					latch.await();
				}
				catch (InterruptedException ex) {
					throw new IOException("Unexpected interruption during index run", ex);
				}

				// collect slave results
				for (int i = 0; i < numberOfSlaves; i++) {
					IndexerSlave slave = indexerSlaves[i];
					IndexerSlaveResult slaveResult = slave.result.get();
					
					Throwable propagateError = slave.propagateError.get();
					if (propagateError != null) {
						throw new IOException("Unexpected error during index run", propagateError);
					}
					
					long offsetBytes = totalNumberOfBytesProcessed;
					long offsetChars = totalNumberOfCharsRead;
					long offsetLines = totalNumberOfLinesRead;
					
					totalNumberOfBytesProcessed = totalNumberOfBytesProcessed + slaveResult.numberOfBytesProcessed;
					totalNumberOfCharsRead = totalNumberOfCharsRead + slaveResult.numberOfCharactersRead;
					totalNumberOfLinesRead = totalNumberOfLinesRead + slaveResult.numberOfLinesRead;

					lostCharEntries = lostCharEntries + Math.max(0, slave.maxNumberOfCharEntries - slaveResult.numberOfCharIndexEntries);
					lostLineEntries = lostLineEntries + Math.max(0, slave.maxNumberOfLineEntries - slaveResult.numberOfLineIndexEntries);
					
					int numberOfCharIndexEntries = slaveResult.numberOfCharIndexEntries;
					long[][] charIndex = slaveResult.charIndex;
					for (int j = 0; j < numberOfCharIndexEntries; j++) {
						long[] entry = charIndex[j];
						characterPositionIndex.put(offsetChars + entry[0], offsetBytes + entry[1]);
					}
					
					
					int numberOfLineIndexEntries = slaveResult.numberOfLineIndexEntries;
					long[][] lineIndex = slaveResult.lineIndex;
					for (int j = 0; j < numberOfLineIndexEntries; j++) {
						long[] entry = lineIndex[j];
						linePositionIndex.put(offsetLines + entry[0], offsetBytes + entry[1]);
					}
					
				}
				
				// pre-install the moved carriage return
				if (movedCR) {
					buffer[0] = (char)CARRIAGE_RETURN_CODE;
					bufferStartIdx = 1;
				}
				else {
					bufferStartIdx = 0;
				}
			}
		}
		finally {
			try {
				executorService.shutdown();
			}
			catch (Throwable t) {
				//ignore
			}
			
			if (br != null) {
				try {
					br.close();
				}
				catch (Throwable t) {
					// irrelevant, we will close the channel anyway
				}
			}
			if (is != null) {
				is.close();
			}
		}
		this.characterPositionIndex = Collections.unmodifiableMap(characterPositionIndex);
		this.linePositionIndex = Collections.unmodifiableMap(linePositionIndex);
		this.numberOfCharacterIndexEntries = characterPositionIndex.size();
		this.numberOfLineIndexEntries = linePositionIndex.size();
		this.numberOfCharacters = totalNumberOfCharsRead;
		this.numberOfLines = (fileSize > 0 ? totalNumberOfLinesRead + 1 : 0);
		this.charsetName = charsetName;
		int pos = -1;
		this.indexedLineNumbers = new long[linePositionIndex.size()];
		for (Long key : linePositionIndex.keySet()) {
			pos++;
			this.indexedLineNumbers[pos] = key;
		}
		Arrays.sort(this.indexedLineNumbers);
		pos = -1;
		this.indexedCharNumbers = new long[characterPositionIndex.size()];
		for (Long key : characterPositionIndex.keySet()) {
			pos++;
			this.indexedCharNumbers[pos] = key;
		}
		Arrays.sort(this.indexedCharNumbers);
	}

	
	/**
	 * Creates a new UNBUFFERED InputStreamReader at the specified file position (byte).
	 * @param filePosition number of the byte the new Reader shall start reading at, see also {@link #getLastKnownFilePosition()}
	 * @return new InputStreamReader, MUST BE CLOSED BY CALLER!
	 * @throws IOException
	 */
	public InputStreamReader createInputStreamReaderAtFilePosition(long filePosition) throws IOException {
		InputStreamReader isr = null;
		FileChannel channel = createChannelAndSetPosition(filePosition);
		isr = new InputStreamReader(Channels.newInputStream(channel), charsetName);
		this.lastKnownFilePosition.set(filePosition);
		return isr;
	}
	
	/**
	 * Creates a new InputStreamReader at the given character position using default buffer size.
	 * @param charNumber number of requested character (starts with 0), MUST BE CLOSED BY CALLER!
	 * @return input stream reader starting with the requested character
	 * @throws IOException
	 */
	public Reader createInputStreamReaderAtChar(long charNumber) throws IOException {
		return createInputStreamReaderAtChar(charNumber, this.defaultChildReaderBufferSize);
	}
	
	
	/**
	 * Creates a new InputStreamReader at the given character position.
	 * @param charNumber number of requested character (starts with 0), MUST BE CLOSED BY CALLER!
	 * @param bufferSize for performance reasons a buffered reader will be used
	 * @return input stream reader starting with the requested character
	 * @throws IOException
	 */
	public Reader createInputStreamReaderAtChar(long charNumber, int bufferSize) throws IOException {
		Reader isr = null;
		if (charNumber >= this.numberOfCharacters) {
			throw new IndexOutOfBoundsException();
		}
		Long filePos = null;
		long ignoredCharacters = 0;
		
		long nearestIndexedCharNumber = findNearestIndexedKeyBefore(indexedCharNumbers, charNumber);
		if (nearestIndexedCharNumber > -1) {
			filePos = characterPositionIndex.get(nearestIndexedCharNumber);
			ignoredCharacters = charNumber - nearestIndexedCharNumber;
		}
		
		if (filePos != null) {
			// we don't want to risk that a resource is open and nobody can close it, see below.
			boolean ok = false;

			long skipped = 0;
			FileChannel channel = null;
			try {
				channel = createChannelAndSetPosition(filePos);
				if (bufferSize > 0) {
					isr = new BufferedReader(new InputStreamReader(Channels.newInputStream(channel), charsetName), bufferSize);
				}
				else {
					isr = new InputStreamReader(Channels.newInputStream(channel), charsetName);
				}
				long[] bytePositionHolder = new long[]{0L};
				skipped = skip(isr, ignoredCharacters, bytePositionHolder, charLengthLookup);
				this.lastKnownFilePosition.set(bytePositionHolder[0]);
				ok = true;
			}
			finally {
				if (!ok && isr != null || skipped < ignoredCharacters) {
					try {
						isr.close();
					}
					catch (Throwable t) {
						// ignore
					}
					try {
						channel.close();
					}
					catch (Throwable t) {
						//ignore
					}
				}
			}
			if (skipped < ignoredCharacters) {
				throw new IOException("Positioning failed (charNumber=" + charNumber + " unreachable) - file truncated since index creation?");
			}
		}
		else {
			throw new IndexOutOfBoundsException();
		}
		return isr;
	}

	/**
	 * Creates a new InputStreamReader at the given line position using default buffer size.
	 * @param lineNumber number of requested line (starts with 0)
	 * @return input stream reader starting with the requested line, MUST BE CLOSED BY CALLER!
	 * @throws IOException
	 */
	public Reader createInputStreamReaderAtLine(long lineNumber) throws IOException {
		return createInputStreamReaderAtLine(lineNumber, this.defaultChildReaderBufferSize);
	}
	
	
	/**
	 * Creates a new InputStreamReader at the given line position.
	 * @param lineNumber number of requested line (starts with 0)
	 * @param bufferSize for performance reasons a buffered reader will be used
	 * @return input stream reader starting with the requested line, MUST BE CLOSED BY CALLER!
	 * @throws IOException
	 */
	public Reader createInputStreamReaderAtLine(long lineNumber, int bufferSize) throws IOException {
		Reader isr = null;
		if (lineNumber >= this.numberOfLines) {
			throw new IndexOutOfBoundsException();
		}
		Long filePos = null;
		long ignoredLines = 0;
		
		long nearestIndexedLineNumber = findNearestIndexedKeyBefore(indexedLineNumbers, lineNumber);
		if (nearestIndexedLineNumber > -1) {
			filePos = linePositionIndex.get(nearestIndexedLineNumber);
			ignoredLines = lineNumber - nearestIndexedLineNumber;
		}
		
		if (filePos != null) {
			// we don't want to risk that a resource is open and nobody can close it, see below.
			boolean ok = false;

			long skipped = 0;
			FileChannel channel = null;
			try {
				channel = createChannelAndSetPosition(filePos);
				if (bufferSize > 0) {
					isr = new BufferedReader(new InputStreamReader(Channels.newInputStream(channel), charsetName), bufferSize);
				}
				else {
					isr = new InputStreamReader(Channels.newInputStream(channel), charsetName);
				}
				long[] bytePositionHolder = new long[]{0L};
				skipped = skipLines(isr, ignoredLines, bytePositionHolder, charLengthLookup);
				this.lastKnownFilePosition.set(bytePositionHolder[0]);
				ok = true;
			}
			finally {
				if (!ok && isr != null || skipped < ignoredLines) {
					try {
						isr.close();
					}
					catch (Throwable t) {
						// ignore
					}
					try {
						channel.close();
					}
					catch (Throwable t) {
						//ignore
					}
				}
			}
			if (skipped < ignoredLines) {
				throw new IOException("Positioning failed (lineNumber=" + lineNumber + " unreachable) - file truncated since index creation?");
			}
		}
		else {
			throw new IndexOutOfBoundsException();
		}
		return isr;
	}


	/**
	 * Returns the physical byte position for the given character position.<br>
	 * Note: Since this is no learning index, it might be a good idea to cache
	 * results externally.<br>
	 * See also: {@link #getLastKnownFilePosition()}
	 * @param charNumber (starts with 0)
	 * @return position of the first byte of that character in the file
	 * @throws IOException
	 */
	public long getFilePositionAtChar(long charNumber) throws IOException {
		long res = -1;
		Long indexHit = characterPositionIndex.get(charNumber);
		if (indexHit != null) {
			res = indexHit.longValue();
		}
		else {
			Reader isr = null;
			try {
				isr = createInputStreamReaderAtChar(charNumber);
			}
			finally {
				try {
					isr.close();
				}
				catch (Throwable t) {
					//ignore
				}
			}
			res = getLastKnownFilePosition();
		}
		return res;
	}
	/**
	 * Returns the physical byte position for the given line position.<br>
	 * Note: Since this is no learning index, it might be a good idea to cache
	 * results externally.<br>
	 * See also: {@link #getLastKnownFilePosition()}
	 * @param lineNumber (starts with 0)
	 * @return position line start
	 * @throws IOException
	 */
	public long getFilePositionAtLine(long lineNumber) throws IOException {
		long res = -1;
		Long indexHit = linePositionIndex.get(lineNumber);
		if (indexHit != null) {
			res = indexHit.longValue();
		}
		else {
			Reader isr = null;
			try {
				isr = createInputStreamReaderAtLine(lineNumber);
			}
			finally {
				try {
					isr.close();
				}
				catch (Throwable t) {
					//ignore
				}
			}
			res = getLastKnownFilePosition();
		}
		return res;
	}
	
	
	/**
	 * Returns the nearest smaller or equal indexed item number for the given key
	 * @param indexedKeys sorted array of indexed keys
	 * @param key search key
	 * @return valid key
	 */
	protected Long findNearestIndexedKeyBefore(long[] indexedKeys, long key) {
		if (key < 0)  {
			throw new IllegalArgumentException("The given position (key) must be a positive value (given="  + key + ").");
		}
		int len = indexedKeys.length;
		long last = -1;
		for (int i = 0; i < len; i++) {
			long current = indexedKeys[i];
			if (current > key) {
				break;
			}
			last = current;
		}
		return new Long(last);
	}
	
	/**
	 * Returns a new Channel
	 * @return new Channel to sourceFile, MUST BE CLOSED by caller!
	 */
	protected FileChannel createChannel() throws FileNotFoundException {
		return new RandomAccessFile(sourceFile, "r").getChannel();
	}

	
	/**
	 * Creates new channel and sets the specified position.
	 * @param filePosition requested position in the channel
	 * @return new channel
	 * @throws IOException
	 */
	public FileChannel createChannelAndSetPosition(long filePosition) throws IOException {
		FileChannel channel = createChannel();
		channel.position(filePosition);
		long realPosition = channel.position();
		if (realPosition != filePosition) {
			try {
				channel.close();
			}
			catch (Throwable t) {
				// ignored
			}
			throw new IndexOutOfBoundsException("Specified filePosition=" + filePosition + " is greater than the file size - file truncated after index creation?");
		}
		return channel;
	}
	
	
	/**
	 * Returns the number of indexed characters.
	 * @return number of index entries
	 */
	public int getNumberOfCharacterIndexEntries() {
		return numberOfCharacterIndexEntries;
	}

	/**
	 * Returns the number of indexed lines.
	 * @return number of index entries
	 */
	public int getNumberOfLineIndexEntries() {
		return numberOfLineIndexEntries;
	}	

	/**
	 * Returns the file size
	 * @return size of file
	 */
	public long getFileSize() {
		return fileSize;
	}

	/**
	 * Returns the number of lines in the file
	 * @return number of lines
	 */
	public long getNumberOfLines() {
		return numberOfLines;
	}

	/**
	 * Returns the number of characters in the file
	 * @return number of characters
	 */
	public long getNumberOfCharacters() {
		return numberOfCharacters;
	}

	/**
	 * Whenever this instance returns a stream at a certain character or
	 * line position, it memorizes the related byte position.<br>
	 * A caller may call this method subsequently to get the physical position. <br>
	 * Since IndexedTextFileAccessor might be accessed concurrently by different threads,
	 * this information is managed thread-locally. Means: This method returns
	 * the least recent position known to the callers thread.
	 * @return last known file position (byte-position) or -1 to indicate unknown
	 */
	public long getLastKnownFilePosition() {
		long res = -1;
		Long memorizedPosition = lastKnownFilePosition.get();
		if (memorizedPosition != null) {
			res = memorizedPosition.longValue();
		}
		return res;
	}

	
	/**
	 * Reads from the reader until the requested number of
	 * characters has been skipped or the end of the stream was reached.
	 * @param reader input
	 * @param numberOfCharactersToSkip
	 * @param bytePositionHolder a single-element long array, where the bytePositionHolder[0] will be incremented while reading characters
	 * @param charLengthLookup the character length lookup maps the length of each character to its length in bytes according to a charset. 
	 * @return number of skipped characters
	 * @throws IOException
	 */
	private static final long skip(Reader reader, long numberOfCharactersToSkip, long[] bytePositionHolder, byte[] charLengthLookup) throws IOException {

		int read = -1;
		long skipped = 0;
		long currentBytePosition = bytePositionHolder[0];

		while (numberOfCharactersToSkip > 0 && (read = reader.read()) != -1)  {

			//determine the new exact position
			currentBytePosition = currentBytePosition + charLengthLookup[read];
			
			numberOfCharactersToSkip--;
			skipped++;
		}
		bytePositionHolder[0] = currentBytePosition;
		return skipped;
	}
	
	/**
	 * Reads from the reader until the given number of lines
	 * has been skipped or the end of the stream was reached.
	 * @param reader input
	 * @param numberOfLinesToSkip specifies the number of lines to be skipped
	 * @param bytePositionHolder a single-element long array, where the bytePositionHolder[0] will be incremented while reading characters
	 * @param charLengthLookup the character length lookup maps the length of each character to its length in bytes according to a charset. 
	 * @return number of skipped lines
	 * @throws IOException
	 */
	private static final long skipLines(Reader reader, long numberOfLinesToSkip, long[] bytePositionHolder, byte[] charLengthLookup) throws IOException {
		int read = -1;
		long skipped = 0;
		
		//last character was a carriage return
		boolean lastCharWasCR = false;
		
		long currentBytePosition = bytePositionHolder[0];
		
		while (numberOfLinesToSkip > 0 && (read = reader.read()) != -1)  {
			
			//determine the new exact position
			currentBytePosition = currentBytePosition + charLengthLookup[read];
			
			if (read == LINE_BREAK_CODE || lastCharWasCR) {
				// new Line
				numberOfLinesToSkip--;
				skipped++;
			}
			if (read == CARRIAGE_RETURN_CODE) {
				lastCharWasCR = true;
			}
			else {
				lastCharWasCR = false;
			}
		}
		if (lastCharWasCR)  {
			skipped++;
		}
		bytePositionHolder[0] = currentBytePosition;
		return skipped;
	}
	
	
	/**
	 * Creates a character length lookup for the given character set.<br>
	 * Internally a static cache is used for performance reasons.
	 * @param charsetName name of character set
	 * @return byte array with length per code for all 65536 char-values
	 */
	private static final byte[] createCharLengthLookup(String charsetName) {
		byte[] charLengthLookup = CHAR_LENGTH_LOOKUP_REGISTRY.get(charsetName);
		if (charLengthLookup == null) {
			charLengthLookup = new byte[65536];
			CharBuffer charBuffer = CharBuffer.allocate(1);
			ByteBuffer byteBuffer = ByteBuffer.allocate(10);
			CharsetEncoder encoder = Charset.forName(charsetName).newEncoder();
			for (int i = 0; i < 65536; i++) {
				char ch = (char)i;
				byteBuffer.clear();
				charBuffer.clear();
				charBuffer.append(ch);
				charBuffer.rewind();
				
				//specifying false here (last parameter) should avoid trouble
				//when encoding surrogates (i.e. for UTF-16 extended)
				encoder.encode(charBuffer, byteBuffer, false);
				charLengthLookup[i] = (byte)byteBuffer.position();
			}
			CHAR_LENGTH_LOOKUP_REGISTRY.put(charsetName, charLengthLookup);
		}
		return charLengthLookup;
	}
	
	
	
	/**
	 * Indexer Slave<br>
	 * Indexing is implemented using the MASTER-SLAVE pattern. While the master
	 * (see constructor of IndexedTextFileAccessor) cuts the work into peaces the
	 * slaves perform the indexing. Finally the master collects the results
	 * and sets up the full index.<br>
	 * Slaves will be recycled.  
	 */
	private static class IndexerSlave implements Runnable {

		/**
		 * Number of index entries this slave may use for characters
		 */
		public int maxNumberOfCharEntries;

		/**
		 * Number of index entries this slave may use for lines
		 */
		public int maxNumberOfLineEntries;
		
		/**
		 * Position within the partition where the slave shall start indexing
		 */
		public int startIdx;
		
		/**
		 * Size of the slaves workspace within the partition
		 */
		public int subPartitionSize;
		
		/**
		 * Current partition
		 */
		public char[] partition;
		
		/**
		 * Result of this slave
		 */
		public final AtomicReference<IndexerSlaveResult> result = new AtomicReference<IndexerSlaveResult>();
		
		/**
		 * lookup to re-calculate the length in bytes of a 
		 * particular character 
		 */
		private final byte[] charLengthLookup;
		
		/**
		 * Errors will be memorized here to be propagated to/by the master
		 */
		public final AtomicReference<Throwable> propagateError = new AtomicReference<Throwable>();
		
		/**
		 * The countdown latch is a slave-to-master signal, the master
		 * waits until all slaves have completed
		 */
		public CountDownLatch latch;
		
		/**
		 * Creates new slave
		 * @param slaveNumber
		 * @param charLengthLookup
		 */
		public IndexerSlave(byte[] charLengthLookup) {
			this.charLengthLookup = charLengthLookup;
		}
		
		@Override
		public void run() {
			try {
				// copy instructions from master and prepare local data structures
				final int maxNumberOfCharEntries = (this.maxNumberOfCharEntries <= subPartitionSize ? this.maxNumberOfCharEntries : this.subPartitionSize);
				final int maxNumberOfLineEntries = (this.maxNumberOfLineEntries <= subPartitionSize ? this.maxNumberOfLineEntries : this.subPartitionSize);
				final int startIdx = this.startIdx;
				final int subPartitionSize = this.subPartitionSize;
				final char[] partition = this.partition;
				final long[][] charIndex = new long[maxNumberOfCharEntries][];
				final long[][] lineIndex = new long[maxNumberOfLineEntries][];
				final int charEntryDistance = maxNumberOfCharEntries == 0 ? 0 : (int)Math.floor((double)subPartitionSize / (double)maxNumberOfCharEntries);
				final int lineEntryDistance = maxNumberOfLineEntries == 0 ? 0 : (int)Math.floor((double)subPartitionSize / (double)maxNumberOfLineEntries);
				
				int availableCharEntries = charEntryDistance == 0 ? 0 : subPartitionSize / charEntryDistance;
				int availableLineEntries = lineEntryDistance == 0 ? 0 : subPartitionSize / lineEntryDistance;
				
				int backupCharEntries = maxNumberOfCharEntries - availableCharEntries;
				int backupLineEntries = maxNumberOfLineEntries - availableLineEntries;

				// Line breaks may consist of a carriage return optionally followed by a line feed.
				// To handle both options, a flag helps.
				boolean lastCharWasCR = false;
				long bytePosAfterCR = 0L;
				boolean lastCharWasIndexed = false;
				
				int charEntryCount = 0;
				int lineEntryCount = 0;
				long numberOfCharactersRead = 0L;
				long numberOfLinesRead = 0L;
	
				long currentBytePos = 0L;
				long lastBytePos = 0L;
				long beforeLastBytePos = 0L;
				
				long lastIndexedLineStartCharNumber = 0L;
				
				long lastIndexedCharNumber = 0L;
				
				for (int i = 0; i < subPartitionSize; i++) {
					int read = (int)partition[startIdx + i];
	
					//increase the byte position using reverse lookup 
					currentBytePos = currentBytePos + charLengthLookup[read];
					
					lastCharWasIndexed = false;
					
					if (read == LINE_BREAK_CODE || lastCharWasCR) {
						// new Line
						numberOfLinesRead++;
						long newLineStart = currentBytePos;
						long newLineStartCharNumber = numberOfCharactersRead;
						
						if (read != LINE_BREAK_CODE) {
							// this position WAS already the line start
							newLineStart = bytePosAfterCR;
							newLineStartCharNumber--;
						}
						if (maxNumberOfLineEntries > lineEntryCount && (newLineStartCharNumber == 0 
								|| newLineStartCharNumber - lastIndexedLineStartCharNumber >= lineEntryDistance
							    || (backupLineEntries > 0 && newLineStartCharNumber - lastIndexedLineStartCharNumber >= lineEntryDistance/2)
								)) {
							if (newLineStartCharNumber - lastIndexedLineStartCharNumber < lineEntryDistance) {
								backupLineEntries--;
							}
							lineEntryCount++;
							lineIndex[lineEntryCount-1] = new long[]{numberOfLinesRead, newLineStart};
							//lastLineStartPos = newLineStart;
							lastIndexedLineStartCharNumber = newLineStartCharNumber;
						}
					}
					if (read == CARRIAGE_RETURN_CODE) {
						lastCharWasCR = true;
						bytePosAfterCR = currentBytePos;
					}
					else {
						lastCharWasCR = false;
					}
					if (maxNumberOfCharEntries > charEntryCount && (numberOfCharactersRead == 0 
							|| numberOfCharactersRead - lastIndexedCharNumber >= charEntryDistance
							|| (backupCharEntries > 0 && numberOfCharactersRead - lastIndexedCharNumber >= charEntryDistance/2)
							)) {
						if (numberOfCharactersRead - lastIndexedCharNumber < charEntryDistance) {
							backupCharEntries--;
						}
						charEntryCount++;
						charIndex[charEntryCount-1] = new long[]{numberOfCharactersRead, lastBytePos};
						//lastCharPos = lastBytePos; 
						lastCharWasIndexed = true;
						lastIndexedCharNumber = numberOfCharactersRead;
					}
					numberOfCharactersRead++;
					beforeLastBytePos = lastBytePos;
					lastBytePos = currentBytePos;
				}
				
				if (!lastCharWasIndexed && charEntryCount < maxNumberOfCharEntries) {
					charEntryCount++;
					charIndex[charEntryCount-1] = new long[]{numberOfCharactersRead-1, beforeLastBytePos};
				}
				if (lastCharWasCR) {
					numberOfLinesRead++;
					if (lineEntryCount < maxNumberOfLineEntries) {
						lineEntryCount++;
						lineIndex[lineEntryCount-1] = new long[]{numberOfLinesRead, bytePosAfterCR};
					}
				}
				
				// slave results for master
				IndexerSlaveResult result = new IndexerSlaveResult(charIndex, lineIndex, currentBytePos, numberOfCharactersRead, numberOfLinesRead, charEntryCount, lineEntryCount);
				this.result.set(result);
			}
			catch (Throwable e) {
				e.printStackTrace();
				this.propagateError.set(e);
			}
			finally {
				this.latch.countDown();
			}
			
		}

	}
	
	/**
	 * Result from an indexer slave
	 */
	private static class IndexerSlaveResult {
		
		/**
		 * The slave uses a simple array to store the index positions:
		 * charIndex[1][235][280] means: second index entry, character no. 235 at byte position 280 
		 */
		public final long[][] charIndex;

		/**
		 * The slave uses a simple array to store the index positions:
		 * lineIndex[7][3895][107898] means: 8th index entry, line no. 3895 starts at byte position 107898 
		 */
		public final long[][] lineIndex;
		
		/**
		 * number of bytes read (total)
		 */
		public final long numberOfBytesProcessed;

		/**
		 * number of characters read (total)
		 */
		public final long numberOfCharactersRead;

		/**
		 * number of lines read (total)
		 */
		public final long numberOfLinesRead;

		/**
		 * number of entries in charIndex
		 */
		public final int numberOfCharIndexEntries;

		/**
		 * number of entries in lineIndex
		 */
		public final int numberOfLineIndexEntries;

		/**
		 * Creates new result
		 * @param charIndex
		 * @param lineIndex
		 * @param numberOfBytesProcessed
		 * @param numberOfCharactersRead
		 * @param numberOfLinesRead
		 * @param numberOfCharIndexEntries
		 * @param numberOfLineIndexEntries
		 */
		public IndexerSlaveResult(long[][] charIndex, long[][] lineIndex, long numberOfBytesProcessed, 
				long numberOfCharactersRead, long numberOfLinesRead, int numberOfCharIndexEntries, int numberOfLineIndexEntries) {
			this.charIndex = charIndex;
			this.lineIndex = lineIndex;
			this.numberOfBytesProcessed = numberOfBytesProcessed;
			this.numberOfCharactersRead = numberOfCharactersRead;
			this.numberOfLinesRead = numberOfLinesRead;
			this.numberOfCharIndexEntries = numberOfCharIndexEntries;
			this.numberOfLineIndexEntries = numberOfLineIndexEntries;
		}
		
	}

	/**
	 * Configuration covers several settings for the indexer.
	 */
	public static class Configuration implements Cloneable, Serializable {
		
		/**
		 * for serialization
		 */
		private static final long serialVersionUID = 1019452617131179610L;

		/**
		 * Default maximum numbers of entries in the file index for character positions <br>
		 * value={@value}
		 */
		public static final int DEFAULT_MAX_NUMBER_OF_CHAR_INDEX_ENTRIES = 10000; 
		
		/**
		 * Default maximum numbers of entries in the file index for line positions<br>
		 * value={@value}
		 */
		public static final int DEFAULT_MAX_NUMBER_OF_LINE_INDEX_ENTRIES = 10000;
		
		/**
		 * Default buffer size in bytes for readers returned by the textfile accessor.<br>
		 * value={@value}
		 */
		public static final int DEFAULT_CHILD_READER_BUFFER_SIZE = 2048;
		
		/**
		 * Default buffer for character reading (number of characters) <br>
		 * value={@value}
		 */
		public static final int DEFAULT_CHAR_BUFFER_SIZE = 2500000;
		
		/**
		 * Default threshold (file size in bytes) for using multiple threads
		 */
		public static final int DEFAULT_MULTI_THREADING_THRESHOLD = 50000;
		
		/**
		 * Default maximum buffer size in bytes while indexing.<br>
		 * value={@value}
		 */
		public static final int DEFAULT_INDEXER_READ_BUFFER_SIZE = 52428800;
		
		/**
		 * Default buffer type to be used by the indexer.<br>
		 * value=MEMORY_MAPPED
		 */
		public static final ParallelFileInputStream.BufferType DEFAULT_INDEXER_READ_BUFFER_TYPE = ParallelFileInputStream.BufferType.MEMORY_MAPPED;
		
		/**
		 * Maximum numbers of entries in the file index for character positions <br>
		 * see {@link #DEFAULT_MAX_NUMBER_OF_CHAR_INDEX_ENTRIES}
		 */
		public int maxNumberOfCharIndexEntries = DEFAULT_MAX_NUMBER_OF_CHAR_INDEX_ENTRIES;
		
		/**
		 * Maximum numbers of entries in the file index for line positions <br>
		 * see {@link #DEFAULT_MAX_NUMBER_OF_LINE_INDEX_ENTRIES}
		 */
		public int maxNumberOfLineIndexEntries = DEFAULT_MAX_NUMBER_OF_LINE_INDEX_ENTRIES;
		
		/**
		 * Buffer size in bytes for readers returned by the textfile accessor.<br>
		 * see {@link #DEFAULT_CHILD_READER_BUFFER_SIZE}
		 */
		public int childReaderBufferSize = DEFAULT_CHILD_READER_BUFFER_SIZE;

		/**
		 * Buffer for character reading (number of characters) <br>
		 * see {@link #DEFAULT_CHAR_BUFFER_SIZE}
		 */
		public int charBufferSize = DEFAULT_CHAR_BUFFER_SIZE;
		
		/**
		 * Threshold (file size in bytes) for using multiple threads<br>
		 * see {@link #DEFAULT_MULTI_THREADING_THRESHOLD}
		 */
		public int multiThreadingThreshold = DEFAULT_MULTI_THREADING_THRESHOLD;

		/**
		 * Maximum buffer size in bytes while indexing.<br>
		 * see {@link #DEFAULT_INDEXER_READ_BUFFER_SIZE}
		 */
		public int indexerReadBufferSize = 52428800;
		
		/**
		 * Buffer type to be used by the indexer.<br>
		 * see {@link #DEFAULT_INDEXER_READ_BUFFER_TYPE}
		 */
		public ParallelFileInputStream.BufferType indexerReadBufferType = DEFAULT_INDEXER_READ_BUFFER_TYPE;
		
		/**
		 * BOM-size (default is 0).<br>
		 * IndexedTextFileAccessor does not support charset auto-detection but can ignore byte order mark by
		 * skipping a specified number of bytes. However, the job to decide whether or not there is
		 * a byte order mark is up to the caller, see also: http://bugs.sun.com/view_bug.do?bug_id=4508058
		 */
		public int bomSize = 0;
		
		@Override
		public Object clone() { 
	        Configuration configuration = null; 
	        try { 
	            configuration = (Configuration) super.clone(); 
	        } 
	        catch (CloneNotSupportedException ex) {
	        	// won't happen
	        }  
	        return configuration; 
	    } 
		
	}

	
}
